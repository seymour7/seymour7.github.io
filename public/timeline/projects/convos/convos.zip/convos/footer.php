
        <div id="footer">
            <p>
                <a href="about.php">About</a> <span>|</span>
                <a href="contact.php">Contact</a> 
            </p>
        </div><!-- #footer -->

    </div><!-- .container -->
</body>

</html>