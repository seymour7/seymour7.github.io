<?php

require_once('config.php');
require_once('lib/recaptchalib.php');

// Will hold our sending errors
$err = array();
$send_success = false;

// Process the message sending
if (isset($_POST['email']) & $config['contact_enabled'])
{
    // Collect info
    $email = $_POST['email'];
    $msg = $_POST['msg'];
    
    // Validate info
    if (strlen($email) == 0)
    {
        $err[] = 'Please enter your email address.';
    }
    else
    {
        if ( ! filter_var($email, FILTER_VALIDATE_EMAIL))
        {
            $err[] = 'Please enter a valid email address.';
        }
    }
    if (strlen($msg) == 0)
    {
        $err[] = 'Please enter a msg to send.';
    } 
    
    
    $privatekey = "6Lc66eUSAAAAACnFfcBZWu-mm6dgF7ulJ1L8AprY";
    $resp = recaptcha_check_answer ($privatekey,
                                  $_SERVER["REMOTE_ADDR"],
                                  $_POST["recaptcha_challenge_field"],
                                  $_POST["recaptcha_response_field"]);

    if ( ! $resp->is_valid)
    {
        // What happens when the CAPTCHA was entered incorrectly
        $err[] = 'The reCAPTCHA wasn\'t entered correctly';
    }
    
    // If there are no errors
    if ( ! count($err) & $config['contact_enabled'])
    {
        // Send email
        $to      = 'seymour7@gmail.com';
        $subject = 'convos.co.za contact page';  
        $message = $msg;

        $headers = 'From:'. $email . "\r\n"; // Set from headers  
        mail($to, $subject, $message, $headers); // Send our email  
        
        $send_success = true;
    }
    
}


?>

<?php include "header.php"; ?>

<div class="login contact">
    <h1>Contact</h1>
    <?php if ( ! $config['contact_enabled']) { ?>
        <p>Contact is disabled.</p>
    <?php } elseif ( ! $send_success) { ?>
        <?php if ($err) { ?>
          <p class="error">
            <?php echo implode('<br />',$err);?>
          </p>
        <?php } ?>
        <form action='contact.php' method='post'>
            <h2>Your email:</h2>
            <p><input type='text' name='email' size='30'></p>
            <h2>Message:</h2>
            <p><textarea cols="46" rows="7" name="msg"></textarea></p>
            <?php
            $publickey = "6Lc66eUSAAAAALFyyvCSx0ewsxpupEJjg5KxZLaZ";
            echo recaptcha_get_html($publickey);
            ?>
            <p class="submit"><input type='submit' value='Send'></p>
        </form>
    <?php } else { ?>
        <p>Message successfully sent.</p>
    <?php } ?>
</div>

<?php include "footer.php"; ?>