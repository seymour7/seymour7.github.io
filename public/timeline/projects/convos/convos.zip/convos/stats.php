<?php

/*
 * Handles stats requests
 */

require_once('config.php');

// Create database connection
$dbh = @mysqli_connect($config['db']['host'], $config['db']['user'], $config['db']['pass'], $config['db']['dbname']);

// Check connection
if (mysqli_connect_errno($dbh))
{
    echo '{}';
    exit;
}

// Try stopping direct script access
if ( ! isset($_GET['action']) ) exit;

// Function select
if ($_GET['action'] == "usersonline") { usersOnline(); } 
//elseif ($_GET['action'] == "sendchat") { sendChat(); } 
//elseif ($_GET['action'] == "nextperson") { nextPerson(); } 

mysqli_close($dbh);

/*
 * Called every x minutes, gets the number of users online
 */
function usersOnline()
{
    global $dbh;
    
    $items = '{}';
    
    // Get the latest num_users count
    $result = mysqli_query($dbh, "SELECT * FROM stats ".
                                 "WHERE name='num_users'");
    
    if ($result->num_rows > 0)
    {
        $row = mysqli_fetch_array($result);

        $arr = array('s' => 0, 'm' => $row['value']);
        $items = '['.json_encode($arr).']';
    }

    // Send all messages to the client
    header('Content-type: application/json');
    echo $items;
}





?>
