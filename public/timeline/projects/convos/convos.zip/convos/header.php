<!DOCTYPE HTML>
<html lang="en">
<head>
<title>convos.co.za</title>
<link type="text/css" rel="stylesheet" href="css/style.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/stats.03.js"></script>
</head>
    
<body>
    <div class="container">

        <div class="header" <?php if (isset($_SESSION['studnum'])) {?>style="text-align:left;"<?php }?>>

            <a href="/"><img src="img/logo.png" alt="convos.co.za" /></a>
            
<?php if (isset($_SESSION['studnum'])) { ?>
            
            <div class="nav"><span id="num_users">0</span> online | <a href="?logout">Logout</a></div>
            
<?php } else { ?>
            
            <div class="stats"><span id="num_users">0</span> online</div>
            
<?php } ?>

        </div>