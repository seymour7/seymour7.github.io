<?php include "header.php"; ?>

    <div class="login about">
      
      <h1>About</h1>
      <p>
        <img src="img/about/meetup.png" alt="Meetup" style="float:right;" />
        Convos pairs you up with another, completely random, UCT student in a one-on-one chat session.
        There is no way for the other user to know any info about you, your identity is completely anonymous.
      </p>
      <p>
        <img src="img/about/anon.png" alt="Anon" style="float:left;padding:0 20px 0 20px;" />
        If you like, however, you may share contact info and meet up in real life.
        Convos does not share your conversations publicly in any way.
      </p>
      <span class="clear"></span>
      
    </div>

<?php include "footer.php"; ?>