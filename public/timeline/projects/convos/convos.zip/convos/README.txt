Convos pairs random UCT students, anonymously, in a chat window using UCT user/pass authentication.

Note: This code is currently in a transition from Ajax to Websockets and will not function 100% correctly.