<?php

/*
|--------------------------------------------------------------------------
| MySQL config
|--------------------------------------------------------------------------
*/
$config['db']['host'] = 'localhost'; // Either a host name or an IP address
$config['db']['port'] = '3306';
$config['db']['user'] = 'root'; // The MySQL user name
$config['db']['pass'] = ''; // The password to login with
$config['db']['dbname'] = 'db1'; // The default database to be used when performing queries

/*
|--------------------------------------------------------------------------
| Site settings
|--------------------------------------------------------------------------
*/
$config['contact_enabled'] = true; //Enables the contact page

/*
|--------------------------------------------------------------------------
| Chat settings
|--------------------------------------------------------------------------
*/
$config['chat_heartbeat_time'] = 2000; //Chat heartbeat time interval
$config['msg_max_len'] = 1200; //Maximum length of message you can send




