<?php

/*
 * Handles client-server chatbox requests
 */

session_start();

require_once('config.php');

// Create database connection
$dbh = @mysqli_connect($config['db']['host'], $config['db']['user'], $config['db']['pass'], $config['db']['dbname']);

// Try stopping direct script access
if ( ! isset($_GET['action']) | ! isset($_SESSION['studnum']) ) exit;

// Function select
if ($_GET['action'] == "chatheartbeat") { chatHeartbeat(); } 
elseif ($_GET['action'] == "sendchat") { sendChat(); } 
elseif ($_GET['action'] == "nextperson") { nextPerson(); } 

mysqli_close($dbh);

/*
 * Called every x seconds, receives messages, checks if connected w/ someone etc.
 */
function chatHeartbeat()
{
    global $dbh;
    
    // Check db connection      is this necessary here?
    //if (mysqli_connect_errno($dbh))
    //    echo '2';
    
    $items = '';
    
    if ($_SESSION['otherid'] == 0)
    {
        // Check my entry in the waiting queue
        if (($result = mysqli_query($dbh, "SELECT * FROM waiting WHERE userid='$_SESSION[id]' AND otherid!='0'")))
        {
            if (mysqli_num_rows($result) > 0) //somebody has connected with me
            {
                // Get ID of connected person
                $row = mysqli_fetch_assoc($result);
                $_SESSION['otherid'] = $row['otherid'];
                $_SESSION['history'][] = $row['otherid'];

                // Delete record from waiting queue
                mysqli_query($dbh, "DELETE FROM waiting WHERE id='$row[id]'");

                // Notify the client that you connected with someone
                $arr = array('s' => 1, 'm' => '');
                $items .= json_encode($arr).',';
            }
            else
            {
                //still waiting for someone
            }
        }
    }
    else //talking to someone
    {
        // Check for new messages
        if (($result = mysqli_query($dbh, "SELECT * FROM messages
                                      WHERE messages.to='$_SESSION[id]' AND messages.from='$_SESSION[otherid]' AND recd=0
                                      ORDER BY id ASC")))
        {
            // Mark all messages as received
            if (mysqli_query($dbh, "UPDATE messages SET recd=1
                                WHERE messages.to='$_SESSION[id]'
                                  AND messages.from='$_SESSION[otherid]'
                                  AND recd=0")) //TODO: DB ROLLBACK!!!
            {
                while ($row = mysqli_fetch_array($result))
                {
                    //$row['message'] = sanitize($row['message']); //already sanitised when put into db

                    if ($row['type'] == 0) //other person sent a msg
                    {
                        $arr = array('s' => 0, 'm' => $row['message']);
                        $items .= json_encode($arr).',';
                    }
                    elseif ($row['type'] == 1) //other person pressed next
                    {
                        $_SESSION['otherid'] = 0;

                        $arr = array('s' => 2, 'm' => '');
                        $items .= json_encode($arr).',';
                    }
                    elseif ($row['type'] == 2) //other person logged out
                    {
                        $_SESSION['otherid'] = 0;

                        $arr = array('s' => 3, 'm' => '');
                        $items .= json_encode($arr).',';
                    }
                }
            }
        }
        
        // Check if other user has disconnected
        if ( $_SESSION['otherid'] != 0 && !isActive($_SESSION['otherid']) )
        {
            $_SESSION['otherid'] = 0;

            $arr = array('s' => 4, 'm' => '');
            $items .= json_encode($arr).',';
        }
        
    }
    
    // Set active true
    if (mysqli_query($dbh, "UPDATE users SET last_heartbeat=NOW() ".
                           "WHERE id='$_SESSION[id]'")){}
    
    // Send all messages to the client
    header('Content-type: application/json');
    if ($items != '')
    {
		$items = substr($items, 0, -1);
        echo '['.$items.']';
    }
    else
    {
        echo '{}';    
    }
}

/**
 * Called when a user sends a chat message, puts the message into the DB
 */
function sendChat()
{    
    global $dbh;
    global $config;
    
    // Check db connection
    if (mysqli_connect_errno($dbh))
        echo '2';
    else
    {
    
    $message = mysqli_real_escape_string($dbh, sanitize($_POST['message']));
    
    if ($_SESSION['otherid'] != 0)
    {
        // Check if other user has disconnected
        if (isActive($_SESSION['otherid']))
        {
            if (strlen($message) < $config['msg_max_len'])
            {
                $sql = "INSERT INTO messages (messages.type, messages.from, messages.to, message, sent) 
                        VALUES (0, $_SESSION[id], $_SESSION[otherid], '$message', NOW())";

                if ( ! mysqli_query($dbh, $sql))
                {
                    echo '2'; //unable to add message to db
                }
                else
                {
                    echo '1'; //message sent successfully
                }
            }
            else
            {
                echo '4'; //message too long to send
            }
        }
        else
        {
            $_SESSION['otherid'] = 0;
            echo '3'; //other user disconnected
        }
    }
    else
    {
        // We are not connected with anyone
        echo '0';
    }
    
    }//end check db connection
}

function sanitize($text)
{
	/*$text = htmlspecialchars($text, ENT_QUOTES);
	$text = str_replace("\n\r","\n",$text);
	$text = str_replace("\r\n","\n",$text);
	$text = str_replace("\n","<br>",$text);*/
    $text=htmlspecialchars($text);
	return $text;
}

/*
 * Called when the "Next" button is pressed
 */
function nextPerson()
{
    global $dbh;
    
    // Check db connection
    if (mysqli_connect_errno($dbh))
        echo "3";
    else
    {
        // If already talking to someone, tell them we moved on
        if ($_SESSION['otherid'] != 0) 
        {
            mysqli_query($dbh, "INSERT INTO messages (messages.type, messages.from, messages.to, message, sent) 
                                VALUES (1, $_SESSION[id], $_SESSION[otherid], '', NOW())");
            
            $_SESSION['otherid'] = 0;
        }
                
        // Exclude users we've chatted to before
        $history_excl = "";
        if (count($_SESSION['history']) > 0)
        {
            $history_excl =  "AND userid NOT IN (".join(",",$_SESSION['history']).")";
        }

        // Look for candidates in the waiting queue
        if (($result = mysqli_query($dbh, "SELECT * FROM waiting WHERE userid!='$_SESSION[id]' AND otherid='0'".$history_excl)))
        {
            if (mysqli_num_rows($result) <= 0) //nobody in the waiting queue with a different id
            {
                $result = mysqli_query($dbh, "SELECT id FROM waiting WHERE userid='$_SESSION[id]'");
                if (mysqli_num_rows($result) > 0)
                    echo "0"; //already waiting
                else
                {
                    // Add to waiting queue
                    $sql = "INSERT INTO waiting (userid)
                            VALUES
                            ('$_SESSION[id]')";

                    if ( ! mysqli_query($dbh, $sql))
                        echo "3";
                    else
                        echo "1"; //added to waiting queue
                }
            }
            else
            {
                // Start chat with person in waiting queue
                $row = mysqli_fetch_assoc($result);

                mysqli_query($dbh, "UPDATE waiting 
                                    SET otherid=$_SESSION[id]
                                    WHERE id=$row[id]");

                $_SESSION['otherid'] = $row['userid'];
                $_SESSION['history'][] = $row['userid'];

                echo "2"; //now chatting with someone
            }
        }
        else
        {
            echo "3";//will need a database rollback here (and probs many other places)
        }
    }//end check db connection
}

/*
 * Returns true if the given user is active
 */
function isActive($id)
{//TODO: MAKE THIS RETURN TRUE IF DONE A CHECK IN THE LAST 30 SEC
    global $dbh;
	$result = mysqli_query($dbh, "SELECT * FROM users WHERE id='$id' AND active=1");
    
    if (mysqli_num_rows($result) > 0)
        return true;
    else
        return false;
}






?>
