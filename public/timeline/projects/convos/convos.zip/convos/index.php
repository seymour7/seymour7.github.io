<?php

//TODO: handle all sql errors, with sql rollback

session_start();

require_once('config.php');
require_once('lib/Database.php');
require_once('lib/Auth.php');

// Create database connection
$db = new Database();

// Process logout request
if (isset($_GET['logout']))
{
    // Notify other person, if in a conversation
    if ($_SESSION['otherid'] != 0) //if already talking to someone, tell them we moved on
    {
        $db->query("INSERT INTO messages (messages.type, messages.from, messages.to, message, sent) "
                                ."VALUES (2, $_SESSION[id], $_SESSION[otherid], '', NOW())");
    }
    
    // Remove from waiting queue if waiting
    $result = $db->query("SELECT * FROM waiting WHERE userid='$_SESSION[id]' AND otherid='0'");
    if ($result->num_rows > 0) //if we are in the waiting queue
    {
        $db->query("DELETE FROM waiting WHERE userid='$_SESSION[id]'");
    }
    
    // Set active to 0
    $db->query("UPDATE users SET active=0
                WHERE id='$_SESSION[id]'");
    
    // Decrement the num users online statistic
    $db->query("UPDATE stats SET value=value-1 WHERE name='num_users'");
    
    // Destroy the session
    $_SESSION = array();
    session_destroy();
    
    header("Location: index.php");
    exit;
}

// Will hold our login errors
$err = array();

// Process login information
if (isset($_POST['studnum']) || isset($_POST['password']))
{
    // Collect your info from login form
    $studnum = strtoupper($_POST['studnum']);
    $password = $_POST['password'];
    
    // If both fields are empty
    if ($studnum == "" || $password == "")
        $err[] = 'Both student number and password must be filled in!';

    if ( ! count($err))
    {
        // Find if user authenticated
        $auth = new Auth($studnum, $password);
        if ($auth->getSuccess())
        {
            // Find if user exists in db
            $result = $db->query("SELECT * FROM users "
                    ."WHERE studnum='".$db->escape($studnum)."'");

            if ($result->num_rows == 1)
            {
                // Check if the user is already logged in
                $row = $result->fetch_assoc();
                
                if ($row['active'] == 0)
                {
                    // Now if everything is correct let's finish his/her/its login
                    do_login($db, $row['id'], $studnum);

                    // Update password to the latest one
                    $safe_password = $db->escape(md5($password));
                    if ($safe_password != $row['password'])
                    {
                        $db->query("UPDATE users SET password='$safe_password' ".
                                   "WHERE id='$row[id]'");
                    }
                }
                else
                { // TODO: check that the user isn't waiting to be timed out
                    $err[] = 'You are already logged in on another computer/browser.';
                    /* future enhancement:
                     * stop multiple logins from same _session_, but allow
                     * logins from different sessions with separate chat ids
                     */
                }
            }
            elseif ($result->num_rows == 0)
            {
                // Add user to the db
                $db->query("INSERT INTO users (studnum, password, regdate) VALUES(". 
                "'". $db->escape($studnum) ."',".
                "'". $db->escape(md5($password)) ."',".
                "NOW())");
                
                // Now if everything is correct let's finish his/her/its login
                do_login($db, $db->getInsertId(), $studnum);
            }
            else
            {
                $err[] = 'The database contains more than one user with your student number.';
            }
        }
        else
        {
            // If curl auth failed, check if the pass matches the prev. stored password
            $result = $db->query("SELECT * FROM users "
                    ."WHERE studnum='".$db->escape($studnum)."' "
                    ."AND password='".$db->escape(md5($password))."'");
            if ($result->num_rows == 0)
            {
                $err[] = 'Wrong student number and/or password!';
            }
            else
            {
                $row = $result->fetch_assoc();
                
                // Now if everything is correct let's finish his/her/its login
                do_login($db, $row['id'], $studnum);
            }
        }
    }
}

function do_login($db, $id, $studnum)
{
    $_SESSION['id'] = $id;
    $_SESSION['studnum'] = $studnum;
    $_SESSION['otherid'] = 0;
    unset($_SESSION['history']);
    $_SESSION['history'] = array();

    // Mark all unreceived msgs as received
    $db->query("UPDATE messages SET recd=1 "
              ."WHERE messages.to='$_SESSION[id]' "
              ."AND recd=0");
    
    // Set active=1    
    $db->query("UPDATE users SET active=1 ".
               "WHERE id='$id'");
    
    // Increment the num users online statistic
    $db->query("UPDATE stats SET value=value+1 WHERE name='num_users'");
}

?>

<?php include "header.php"; ?>



<?php
if ( ! isset($_SESSION['studnum'])) {
?>


    
    <div class="login">
      <?php if ($err) { ?>
      <p class="error">
        <?php echo implode('<br />',$err);?>
      </p>
      <?php } ?>
      <form method="post" action="index.php">
        <h2>UCT Student Number</h2>
        <p><input type="text" name="studnum" value="" placeholder="UCT Student Number"></p>
        <h2>Password</h2>
        <p><input type="password" name="password" value="" placeholder="Password"></p>
        <p class="submit"><input type="submit" name="enter" value="Login"></p>
      </form>
      
    </div>




    

<?php
}
else {
    
$resuming = 0;
// Check if we disconnected (will always be done before a heartbeat or sendmsg is sent)
$result = $db->query("SELECT * FROM users WHERE id='$_SESSION[id]' AND active=0");
if ( $result->num_rows > 0 ) //TODO: problem, this occurs after a login
{
    $_SESSION['otherid'] = 0;
    unset($_SESSION['history']);
    $_SESSION['history'] = array();
    
    // Mark unrecd msgs as recd
    $db->query("UPDATE messages SET recd=1 ".
               "WHERE messages.to='$_SESSION[id]' ".
               "AND recd=0");
    
    // Set active=1    
    $db->query("UPDATE users SET active=1 ".
               "WHERE id='$_SESSION[id]'");
    
    // Increment the num users online statistic
    $db->query("UPDATE stats SET value=value+1 WHERE name='num_users'");
}
else
{ //we are not returning from a disconnect
    if ($_SESSION['otherid'] != 0)
        $resuming = 1;
}

?>


    <div class="chatbox">
        <div id="chatboxheader">
            <a id="next" href="javascript:void(0)">Next</a>
            <p style="padding-top:7px;">Logged in as <b><?php echo $_SESSION['studnum']; ?></b></p>
            <div style="clear:both"></div>
        </div>	
        <div id="chatboxcontent"><?php
        /*if(file_exists("log.html") && filesize("log.html") > 0){
            $handle = fopen("log.html", "r");
            $contents = fread($handle, filesize("log.html"));
            fclose($handle);

            echo $contents;
        }*/
        ?></div>

        <form name="chatboxinput" id="chatboxinput" action="">
            <input name="chatboxmsg" type="text" id="chatboxmsg" size="63" autocomplete="off" />
            <input name="chatboxbutton" type="submit"  id="chatboxbutton" value="Send" />
        </form>
    </div>
  
  
    <script type="text/javascript">
    var Settings = {
        chatHeartbeatTime: '<?php echo $config['chat_heartbeat_time']; ?>',
        resuming: <?php echo $resuming; ?>
    };
    </script>
    <script type="text/javascript" src="js/chat.03.js"></script>
    

  
    
<?php
}
?>
    

<?php include "footer.php"; ?>