/* 
 * stats.js
 * Makes stats requests
 */

function statsHeartbeat()
{	
    //console.log("Stats heartbeat called");
    
	$.ajax({
        url: "stats.php?action=usersonline",
        cache: false,
        dataType: "json",
        success: function(data) {

		$.each(data, function(i,item){
			if (item) { // fix strange ie bug

                if (item.s == 0)
                {
                    $("#num_users").text(item.m);
                }
                /*else if (item.s == 1)
                {
                    appendMsgToChatbox("Server", "Connected with someone.");
                }*/
			}
		});
		
		setTimeout('statsHeartbeat();', statsHeartbeatTime);
        
	}});
}

var statsHeartbeatTime = 60000;

$(document).ready(function(){

statsHeartbeat();
    
});