/* 
 * chat.js
 * Chatbox functionality
 */

function appendMsgToChatbox(from, msg)
{
    var oldscrollHeight = $("#chatboxcontent").attr("scrollHeight") - 20;
    
    if (from == "Server")
    {
        $("#chatboxcontent").append('\
        <div class="chatboxmessage orangetext">\n\
            <span class="chatboxmessagecontent">'+msg+'</span>\n\
        </div>'
        );
    }
    else if (from == "Me")
    {
        $("#chatboxcontent").append('\
        <div class="chatboxmessage">\n\
            <span class="chatboxmessagefrom bluetext"><b>'+from+':&nbsp;&nbsp;</b></span>\n\
            <span class="chatboxmessagecontent">'+msg+'</span>\n\
        </div>'
        );
    }
    else if (from == "Anon")
    {
        $("#chatboxcontent").append('\
        <div class="chatboxmessage">\n\
            <span class="chatboxmessagefrom redtext"><b>'+from+':&nbsp;&nbsp;</b></span>\n\
            <span class="chatboxmessagecontent">'+msg+'</span>\n\
        </div>'
        );
    }
    
           
    var newscrollHeight = $("#chatboxcontent").attr("scrollHeight") - 20;
    if(newscrollHeight > oldscrollHeight){
        $("#chatboxcontent").animate({ scrollTop: newscrollHeight }, 'normal'); //Autoscroll to bottom of div
    }
}

function chatHeartbeat()
{
    //console.log("Heartbeat running.");
	
	$.ajax({
	  url: "chat.php?action=chatheartbeat",
	  cache: false,
	  dataType: "json",
	  success: function(data) {

		$.each(data, function(i,item){
			if (item) { // fix strange ie bug

                if (item.s == 0)
                {
                    appendMsgToChatbox("Anon", item.m);
                }
                else if (item.s == 1)
                {
                    appendMsgToChatbox("Server", "Connected with someone.");
                }
                else if (item.s == 2) //other person pressed next
                {
                    appendMsgToChatbox("Server", "Anon has moved on to the next person.");
                }
                else if (item.s == 3) //other person logged out
                {
                    appendMsgToChatbox("Server", "Anon has logged out.");
                }
                else if (item.s == 4) //other person disconnected/timed out
                {
                    appendMsgToChatbox("Server", "Anon has disconnected (x second timeout).");
                }
                else if (item.s == 5) //continue chat after leaving and coming back to page
                {
                    appendMsgToChatbox("Server", "Continuing chat with anon....");
                }
			}
		});
		
		setTimeout('chatHeartbeat();', chatHeartbeatTime);
	}});
}

var chatHeartbeatTime = Settings.chatHeartbeatTime;

$(document).ready(function(){

chatHeartbeat(); //initiate the heartbeat

if (Settings.resuming)
    appendMsgToChatbox("Server", "Resuming chat with Anon.");
else
    appendMsgToChatbox("Server", "Welcome! Click \'next\' to start chatting with someone.");

/**
 * If user submits the form
 */
$('#chatboxinput').submit(function() {	

    message = $('#chatboxmsg').val();
    
    $('#chatboxmsg').val('');
    $('#chatboxmsg').focus();

    if (message !== '') {
        $.post("chat.php?action=sendchat", {message: message} , function(data){

            if (data == 0) //not connected with anyone
            {
                appendMsgToChatbox("Server", "Could not send message, you are not connected with anyone.");
            }
            else if (data == 1) //msg sent successfully
            {
                appendMsgToChatbox("Me", $('<div/>').text(message).html()); //escape html special chars
            }
            else if (data == 2) //unable to add message to db
            {
                appendMsgToChatbox("Server", "Could not send message due to server error.");
            }
            else if (data == 3) //other user disconnected
            {
                appendMsgToChatbox("Server", "Could not send message as anon has disconnected.");
            }
            else if (data == 4) //msg too long
            {
                appendMsgToChatbox("Server", "Message too long to send.");
            }
            
        });
    }
    
    send();

    return false; //stops form from being submitted
});

/**
 * User clicks the next button
 */ 
$("#next").click(function() {
    $.post("chat.php?action=nextperson", function(data) {
        
        if (data == 0) //already waiting in the queue
        {
            appendMsgToChatbox("Server", "You are already waiting in the queue.");
        }
        else if (data == 1) //added to waiting queue
        {
            appendMsgToChatbox("Server", "Added to the waiting queue.");
        }
        else if (data == 2) //now chatting with someone
        {
            appendMsgToChatbox("Server", "You are now connected with someone.");
        }
        else if (data == 3) //error connecting to db/making query
        {
            appendMsgToChatbox("Server", "Error connecting to chat database.");
        }
        
    });
});


//Websocketz
var socket;

var host = "ws://localhost:9000/uct_chat/websockets/chatserver.php";
try{
    socket = new WebSocket(host);
    alert('WebSocket - status '+socket.readyState);
    socket.onopen    = function(msg){ alert("Welcome - status "+this.readyState); };
    socket.onmessage = function(msg){ alert("Received: "+msg.data); };
    socket.onclose   = function(msg){ alert("Disconnected - status "+this.readyState); };
}
catch(ex){ alert(ex); }
//$("msg").focus();

function send(){
  //var txt,msg;
  //txt = $("msg");
  //msg = txt.value;
  //if(!msg){ alert("Message can not be empty"); return; }
  //txt.value="";
  //txt.focus();
  try{ socket.send("test"); /*log('Sent: '+msg);*/ } catch(ex){ alert(ex); }
}
function quit(){
  alert("Goodbye!");
  socket.close();
  socket=null;
}


}); //end document ready function