<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

// OLD CODE FOR STORING NUM USERS ONLINE HISTORY

//require_once('../config.php');
//require_once('../lib/Database.php');
//
//// Create database connection
//$db = new Database();
//
//// Get the latest num_users count
//$result = $db->query("SELECT * FROM stats_users_online ".
//                     "ORDER BY timestamp DESC LIMIT 1");
//
//if ($result->num_rows > 0)
//{
//    $latest_usr_count = mysqli_fetch_array($result);
//    
//    date_default_timezone_set('Africa/Johannesburg');
//    
//    echo $latest_usr_count['timestamp']."<br />";
//    echo strtotime($latest_usr_count['timestamp'])."<br />";
//    echo strtotime('-5 minutes')."<br />";
//    echo date("Y-m-d H:i:s",strtotime('-5 minutes'))."<br />";
//    
//    if (strtotime($latest_usr_count['timestamp']) <= strtotime('-5 minutes'))
//    {
//        echo "OLDER";
//    }
//    else
//    {
//        echo "not older";
//    }
//    
//}
//
//
////$result = $db->query("SELECT * FROM users WHERE active=1");
//
////$db->query("INSERT INTO stats_users_online (num_users) VALUES($result->num_rows)");


?>
