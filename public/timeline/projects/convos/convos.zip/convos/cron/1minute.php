<?php
/*
 * Cron job called every minute
 */

require_once('../config.php');
require_once('../lib/Database.php');

// Create database connection
$db = new Database();

// Get inactive users
$result = $db->query("SELECT * FROM users "
                    ."WHERE last_heartbeat < NOW() - INTERVAL 60 SECOND "
                    ."AND active=1");

// Mark inactive users as inactive
while ($row = mysqli_fetch_array($result))
{
    // Set user as inactive
    $db->query("UPDATE users SET active=0
                WHERE id='$row[id]'");
    
    // Remove from waiting queue (both waiting and connected)
    $waiters = $db->query("SELECT * FROM waiting WHERE userid='$row[id]'");
    if ($waiters->num_rows > 0) //if we are in the waiting queue
    {
        $db->query("DELETE FROM waiting WHERE userid='$row[id]'");
    }
}

// Update number of users online
$result = $db->query("SELECT * FROM users WHERE active=1");
$db->query("UPDATE stats SET value=$result->num_rows WHERE name='num_users'");


?>