<?php
/**
 * Database class
 */

class Database
{
    protected $_dbh; //database handler
    
    /*
     * Constructor, connects to the database
     */
    public function __construct()
    {        
        global $config;

        $this->_dbh = new mysqli(
                $config['db']['host'], 
                $config['db']['user'], 
                $config['db']['pass'], 
                $config['db']['dbname'], 
                $config['db']['port']
                )
            or die('There was a problem connecting to the database');
    }

    /*
     * Queries the database
     */
    public function query($sql)
    {
        if (!$result = $this->_dbh->query($sql))
            die('There was an error running the query [' . $this->_dbh->error . ']');
        
        return $result;
    }
    
    /*
     * Returns the last insert id
     */
    public function getInsertId()
    {       
        return $this->_dbh->insert_id;
    }
    
    /*
     * Performs a mysqli_real_escape_string()
     */
    public function escape($str)
    {       
        return $this->_dbh->real_escape_string($str);
    }

    /*
     * Destructor
     */
    public function __destruct()
    {
        $this->_dbh->close();
    }

} // end class Database