<?php
/**
 * UCT user authentication class
 */

class Auth 
{
    private $eid;
    private $pw;
    private $login_url = 'https://vula.uct.ac.za/portal/xlogin';
    private $success = FALSE;

    public function __construct($eid, $pw)
    {
        $this->eid = $eid;
        $this->pw = $pw;
        $this->attemptLogin();
    }

    private function attemptLogin() 
    {        
        // Init new curl session and set curl handler
        $ch = curl_init();
        // Set the url for the post form login
        curl_setopt($ch, CURLOPT_URL, $this->login_url);
        // Enable http post
        curl_setopt ($ch, CURLOPT_POST, TRUE);
        // Set post parameters (form data)
        curl_setopt ($ch, CURLOPT_POSTFIELDS, 'eid='.$this->eid.'&pw='.$this->pw.'&submit=Login');
        // Return results as a string instead of printing
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, TRUE);
        // Pretend to be a browser
        curl_setopt ($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6");
        // Stop cURL from verifying the peer's certificate
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        // Execute the form login
        curl_exec($ch);
        // Determine auth based on the http response code
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($httpcode == 302) //302 Found
            $this->success = TRUE;
        else //200 OK
            $this->success = FALSE;
        // Close session and free resources
        curl_close ($ch);
    }

    public function getSuccess() 
    {
        return $this->success;
    }
}