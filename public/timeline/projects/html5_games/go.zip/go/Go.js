////////////////////////////////////
//        GLOBAL VARIABLES        //
////////////////////////////////////

/** Target frames per second  
    Type: Integer
*/
var FPS = 60;
/** Time between frames 
    Type: Integer
*/
var MILLISECONDS_BETWEEN_FRAMES = (1 / FPS) * 1000;
/** A reference to the canvas element  
    Type: HTMLCanvasElement
*/
var g_canvas = null;
/** A reference to the 2D context of the canvas element
    Type: CanvasRenderingContext2D
*/
var g_context2D = null;
/** A global reference to the in-memory canvas used as a back buffer
    Type: HTMLCanvasElement
*/
var g_backBuffer = null;
/** A global reference to the backbuffer 2D context
    Type: CanvasRenderingContext2D
*/
var g_backBufferContext2D = null;

var g_gameID = 956574;

var g_playerID = Math.floor(Math.random()*10000);

var g_turn = 'w';


////////////////////////////////////
//    APPLICATION ENTRY POINT     //
////////////////////////////////////

/**
    The entry point of the application is set to the init function
*/
window.onload = init;

/**
    Function that gets this party started
*/
function init()
{
    // Assign references to the canvas elements and later, their 2D contexts
    g_canvas = document.getElementById('canvas');

    // If the g_canvas.getContext function does not exist it is a safe bet that
    // the current browser does not support the canvas element
    if (g_canvas.getContext)
    {
        g_context2D = g_canvas.getContext('2d');
        g_backBuffer = document.createElement('canvas');
        g_backBuffer.width = g_canvas.width;
        g_backBuffer.height = g_canvas.height;
        g_backBufferContext2D = g_backBuffer.getContext('2d');

        // Create the Sprite Manager
        SpriteManager.startupSpriteManager();
    }
}


////////////////////////////////////
//        SPRITE MANAGEMENT       //
////////////////////////////////////

/**
    A manager for all the sprites used in the game
*/
var SpriteManager =
{
    /** An array of sprite sources to load
        Type: Array
    */
    spriteSources: [
        'sprites/white.png',
        'sprites/black.png',
        'sprites/w_pot.png',
        'sprites/b_pot.png'
    ],
    /** An array of sprites
        Type: Array
    */
    gameSprites: new Array(),
    /** The ID for the interval which displays the loading screen so we can clear it afterwards
        Type: ID
    */
    loadScrIntervalId: null,
    /** True if the sprites supplied to the sprite manager are all loaded, false otherwise
        Type: Boolean
    */
    spritesLoaded: false,
    
    /**
        Initialises the Sprite Manager
    */
    startupSpriteManager: function ()
    {
        for (var i = 0; i < this.spriteSources.length; i++)
        {
            // Create new Image object and add to array
            this.gameSprites[i] = new Image;
            
            // Assign the .src property of the Image object so they start loading
            this.gameSprites[i].src = this.spriteSources[i];
            
            // Display show the loading screen while the sprites load
            this.loadScrIntervalId = setInterval(function(){SpriteManager.displayLoadingScreen();}, MILLISECONDS_BETWEEN_FRAMES);
        }
    },
    
    /**
        Displays the loading screen as the sprites load
    */
    displayLoadingScreen: function ()
    {
        if (!this.spritesLoaded)
        {
            var numLoaded = 0;
            for (var i in this.gameSprites)
            {
                if (this.gameSprites[i].complete)
                    numLoaded++;
            }

            if (numLoaded == this.spriteSources.length)
            {
                this.spritesLoaded = true;

                // Create the WebSockets Manager
                WebSocketsManager.startupWebSocketsManager();
                
                // Create the GameObjectManager
                GameObjectManager.startupGameObjectManager();
                
                // Create the Room Manager
                //RoomManager.startupRoomManager();
            }
            else
            {
                // Clear the drawing context
                g_context2D.clearRect(0, 0, g_canvas.width, g_canvas.height);
                
                // Draw a rectangular loading bar
                g_context2D.fillStyle = "#FF0000";
                g_context2D.fillRect(g_canvas.width/2-numLoaded*30, g_canvas.height/2-10, numLoaded*60, 20);
            }
        }
        else
        {
            // Stop trying to draw the loading screen
            clearInterval(this.loadScrIntervalId);
        }
    }
};


////////////////////////////////////
//      WEBSOCKETS MANAGEMENT     //
////////////////////////////////////

/**
    A manager for using WebSockets
*/
var WebSocketsManager =
{
    /** The URL to the WebSockets server
        Type: String
    */
    host: "ws://localhost:12345/go/websocket/go.php",
    /** The ID for the interval which displays the loading screen so we can clear it afterwards
        Type: Object
    */
    socket: null,

    /**
        Initialises the WebSockets Manager
    */
    startupWebSocketsManager: function ()
    {
        if (!("WebSocket" in window))
        {
            // The user does not have WebSockets
            this.log('Browser does not support WebSockets')
        }
        else
        {  
            // The user has WebSockets  
            try
            {
                this.socket = new WebSocket(this.host);
                this.log('WebSocket - status ' + this.socket.readyState);
                this.socket.onopen = function(msg)
                {
                    WebSocketsManager.log('Welcome - status ' + this.readyState);
                    WebSocketsManager.send(g_gameID + ':' + g_playerID + ':' + 'reg' + ':' + '0');
                };
                this.socket.onclose   = function(msg)
                {
                    WebSocketsManager.log("Disconnected - status " + this.readyState);
                };
                this.socket.onmessage = function(msg)
                {
                    WebSocketsManager.log("Received: " + msg.data);
                    
                    var msg = msg.data.split(':');
                    var type = msg[0];
                    var val = msg[1];

                    if (type == 'col')
                    {
                        window.g_colour = val;
                        RoomManager.startupRoomManager();
                    }
                    else if (type == 'turn')
                    {
                        window.g_turn = val;
                    }
                    else
                    {
                        // Run the multiplayer event of all the game objects
                        for (x in GameObjectManager.gameObjects)
                        {
                            if (GameObjectManager.gameObjects[x].multiplayer)
                            {
                                GameObjectManager.gameObjects[x].multiplayer(type, val);
                            }
                        }
                    }
                };
            }
            catch(ex){ this.log(ex); }
        }  
    },

    /**
        Sends messages to the WebSockets server
        Param: msg The message to send
    */
    send: function (/**String*/ msg)
    {
        try
        {
            this.socket.send(msg); // only send when connected to server
            this.log('Sent: ' + msg);
        }
        catch(ex){ this.log(ex); }
    },

    /**
        Logs messages for the user
        Param: msg The message to log
    */
    log: function (/**String*/ msg)
    {
        document.getElementById("scktlog").innerHTML = "<br>" + msg + document.getElementById("scktlog").innerHTML;
    }
};


////////////////////////////////////
//     GAME OBJECT MANAGEMENT     //
////////////////////////////////////

/**
    A manager for all the objects in the game
*/
var GameObjectManager =
{
    /** An array of game objects 
        Type: Array
    */
    gameObjects: new Array(),
    /** Array for all the keyboard keys that are currently pressed
        Type: Array
    */
    //keysDown: new Array(),
    /** Array for all the keyboard keys that are currently pressed
        Type: Array
    */
    //mouseDown: false,
    /** Array for all the keyboard keys that are currently pressed
        Type: Array
    */
    mousePos: { x: 0, y: 0 },
    
    /**
        Initialises the Game Object Manager
    */
    startupGameObjectManager: function ()
    {
        // Use setInterval to call the draw function
        setInterval(function(){GameObjectManager.update();}, MILLISECONDS_BETWEEN_FRAMES);
        
        // Watch for keyboard events
        //document.onkeydown = function(event){GameObjectManager.keyDown(event);}
        //document.onkeyup = function(event){GameObjectManager.keyUp(event);}
        
        // Watch for mouse events
        g_canvas.onmousedown = function(e)
        {
            //GameObjectManager.mouseDown = true;
            
            var mouseX = e.pageX - g_canvas.offsetLeft;
            var mouseY = e.pageY - g_canvas.offsetTop;
            
            GameObjectManager.mousePos.x = mouseX;
            GameObjectManager.mousePos.y = mouseY;
            
            for (n in GameObjectManager.gameObjects)
            {
                if (GameObjectManager.gameObjects[n].globalMouseDown)
                {
                    GameObjectManager.gameObjects[n].globalMouseDown(mouseX, mouseY);
                }
            }
            
            /*for (n in GameObjectManager.gameObjects)
            {
                // If the click is in the region of the object's sprite
                if
                (
                    (
                        (mouseX >= GameObjectManager.gameObjects[n].x) 
                        && (mouseX < GameObjectManager.gameObjects[n].x + SpriteManager.gameSprites[GameObjectManager.gameObjects[n].spriteIndex].width)
                    ) 
                    && 
                    (
                        (mouseY >= GameObjectManager.gameObjects[n].y) 
                        && (mouseY < GameObjectManager.gameObjects[n].y + SpriteManager.gameSprites[GameObjectManager.gameObjects[n].spriteIndex].height)
                    )
                )
                {
                    // Check if the mousedown event exists and execute
                    if (GameObjectManager.gameObjects[n].mouseDown)
                    {
                        GameObjectManager.gameObjects[n].mouseDown();
                    }
                }
            }*/
        }
        /*g_canvas.onmouseup = function(e)
        {
            GameObjectManager.mouseDown = false;
            
            for (n in GameObjectManager.gameObjects)
            {
                if (GameObjectManager.gameObjects[n].mouseUp)
                {
                    GameObjectManager.gameObjects[n].mouseUp();
                }
            }
        }
        g_canvas.onmousemove = function(e)
        {
            var mouseX = e.pageX - g_canvas.offsetLeft;
            var mouseY = e.pageY - g_canvas.offsetTop;
            
            GameObjectManager.mousePos.x = mouseX;
            GameObjectManager.mousePos.y = mouseY;
            
            //var text = mouseX + ', ' + mouseY + ', | mousedown: ' + GameObjectManager.mouseDown;     
            //document.getElementById('debug').innerHTML = text;
        }*/
    },
    
    /**
        The render loop
    */
    update: function ()
    {
        // Run the step event of all the game objects
        for (x in this.gameObjects)
        {
            if (this.gameObjects[x].step)
            {
                this.gameObjects[x].step();
            }
        }
    },
    
    /**
        The render loop
    */
    draw: function ()
    {
        // Clear the back buffer drawing context
        g_backBufferContext2D.clearRect(0, 0, g_backBuffer.width, g_backBuffer.height);

        // Draw the game objects to the back buffer
        for (x in this.gameObjects)
        {
            if (this.gameObjects[x].draw)
            {
                this.gameObjects[x].draw();
            }
        }
        
        // Clear the displayed canvas's drawing context
        g_context2D.clearRect(0, 0, g_canvas.width, g_canvas.height);
        
        // Now copy the back buffer to the displayed canvas
        g_context2D.drawImage(g_backBuffer, 0, 0);
    }//,
    
    /**
        Works with keyUp to maintain the array of all keyboard keys that are currently pressed
        Param: event
    */
    /*keyDown: function(event)
    {
        if (!this.keysDown[event.keyCode])
        {
            this.keysDown[event.keyCode] = true;
        }
    },*/

    /**
        Works with keyDown to maintain the array of all keyboard keys that are currently pressed
        Param: event
    */
    /*keyUp: function(event)
    {
        if (this.keysDown[event.keyCode])
        {
            this.keysDown[event.keyCode] = false;
        }
    }*/
};


////////////////////////////////////
//         ROOM MANAGEMENT        //
////////////////////////////////////

/**
    A manager for the room(s - in the future) in the game
*/
var RoomManager =
{
    /**
        Initialises the Room Manager
    */
    startupRoomManager: function ()
    {
        //window.obj_wPot = new Pot().startupGameObject(2, 10, 10);
        //window.obj_bPot = new Pot().startupGameObject(3, g_canvas.width - 110, g_canvas.height - 110);
        
        window.obj_grid = new Grid().startupGameObject(0, 0, 0);
    }
};


////////////////////////////////////
//     GAME OBJECT BASE CLASS     //
////////////////////////////////////

/**
    The base class for all objects that appear in the game
    Note: Couldn't use JSON formatting because of inheritance issues
*/
function GameObject ()
{
    /** The index number of the sprite to use for this object
        Type: Integer
    */
    this.spriteIndex = null;
    /** The position on the X axis
        Type: Integer
    */
    this.x = 0;
    /** The position on the Y axis
        Type: Integer
    */
    this.y = 0;
    
    /**
        Initialises the game object and adds it to the game object list
        Param: spriteIndex The index number of the sprite to use for this object
        Param: x The position on the X axis
        Param: y The position on the Y axis
    */
    this.startupGameObject = function (/**Integer*/ spriteIndex, /**Integer*/ x, /**Integer*/ y)
    {
        // Add this game object to the game object list
        GameObjectManager.gameObjects.push(this);
        
        // Assign local variables
        this.spriteIndex = spriteIndex;
        this.x = x;
        this.y = y;
        
        // Run the create event in the object
        if (this.create)
        {
            this.create();
        }
        
        // Return a reference to this object
        return this;
    };
    
    /**
        Draws this game object to the back buffer
    */
    this.draw = function ()
    {
        g_backBufferContext2D.drawImage(
            SpriteManager.gameSprites[this.spriteIndex],
            /*Math.round*/(this.x),
            /*Math.round*/(this.y)
        );
    };
}


////////////////////////////////////
//          GAME OBJECTS          //
////////////////////////////////////

/**
    The pots
    Note: Couldn't use JSON formatting because of inheritance issues
*/
function Pot ()
{
    /** The speed of the paddle in pixels per frame
        Type: Integer
    */
    this.speed = 5;
    /** True if this is the paddle the player controls
        Type: Boolean
    */
    this.player = false;
    /** The ID of this paddle (left or right)
        Type: String
    */
    this.padId = null;
    
    /**
        Create event for the game object
    */
    this.create = function ()
    {
    };
    
    /**
        Keyboard event for the game object
    */
    this.keyboard = function ()
    {
    };
    
    /**
        Multiplayer event for the game object
    */
    this.multiplayer = function (msg)
    {
    };
    
    /**
        Mouse down event for the game object
    */
    this.mouseDown = function ()
    {
        new Stone().startupGameObject(1, GameObjectManager.mousePos.x, GameObjectManager.mousePos.y);
    };
}
Pot.prototype = new GameObject;

/**
    The stones
    Note: Couldn't use JSON formatting because of inheritance issues
*/
function Stone ()
{
    /** The speed of the ball in pixels per frame
        Type: Integer
    */
    this.speed = 3;
    /** The direction of the ball in radians clockwise from east
        Type: Integer
    */
    this.direction = Math.PI*1.25;
    
    /**
        Step event for the game object
    */
    this.step = function ()
    {
        if (GameObjectManager.mouseDown)
        {            
            this.x = GameObjectManager.mousePos.x;
            this.y = GameObjectManager.mousePos.y;
        }
    };
}
Stone.prototype = new GameObject;

/**
    The grid
    Note: Couldn't use JSON formatting because of inheritance issues
*/
function Grid ()
{
    /** The top left position of the grid
        Type: Array
    */
    this.pos = { x: 200, y: 50 };
    /** The direction of the ball in radians clockwise from east
        Type: Integer
    */
    this.cellWidth = 50;
    /** The direction of the ball in radians clockwise from east
        Type: Integer
    */
    this.cellHeight = 50;
    /** The number of horizontal cells
        Type: Integer
    */
    this.hCells = 10;
    /** The number of vertical cells
        Type: Integer
    */
    this.vCells = 10;
    /** The direction of the ball in radians clockwise from east
        Type: Integer
    */
    this.grid = new Array();
    /** The number of vertical cells
        Type: Integer
    */
    this.stoneSprite = 0;

    /**
        Create event for the game object
    */
    this.create = function ()
    {
        for ( var x = 0; x <= this.vCells; x += 1 )
        {
            for ( var y = 0; y <= this.hCells; y += 1 )
            {
                this.grid[x] = new Array;
                this.grid[x][y] = false;
            }
        }
        GameObjectManager.draw();
        
        if ( g_colour == 'w' )
        {
            this.stoneSprite = 0;
        }
        else if ( g_colour == 'b' )
        {
            this.stoneSprite = 1;
        }
        
        if ( g_colour == 'w' )
        {
            // Send the size of the grid to the server
            WebSocketsManager.send(g_gameID + ':' + g_playerID + ':' + 'gridSize' + ':' + this.hCells + 'x' + this.vCells);
        }
        else
        {
            // Request the current state of the grid
            WebSocketsManager.send(g_gameID + ':' + g_playerID + ':' + 'gridState' + ':' + '0');
        }
    };
    
    /**
        Multiplayer event for the game object
    */
    this.multiplayer = function (type, val)
    {
        // Receives the entire grid
        if ( type == 'gridState' )
        {
            if ( val != '' )
            {
                val = val.split('-');
                for ( i = 0; i < val.length; i += 3 )
                {
                    this.grid[val[i]][val[i+1]] = val[i+2];
                }
                GameObjectManager.draw();
            }
        }
        
        // Receives a new stone placement from another player
        if ( type == 'newStone' )
        {
            val = val.split('x');
            this.grid[val[0]][val[1]] = val[2];
            GameObjectManager.draw();
            
            // Change who's turn it is
            if (g_turn == 'w')
            {
                g_turn = 'b';
            }
            else
            {
                g_turn = 'w';
            }
        }
        
        // Delete stones that probably have no liberties left
        if ( type == 'delStones' )
        {
            val = val.split('x');
            for ( i = 0; i < val.length; i += 2 )
            {
                this.grid[val[i]][val[i+1]] = false;
            }
            GameObjectManager.draw();
        }
    };
    
    /**
        Step event for the game object
    */
    this.step = function ()
    {
    };
    
    /**
        Mouse down event for the game object
    */
    this.mouseDown = function ()
    {
    };
    
    /**
        Global mouse down event for the game object
    */
    this.globalMouseDown = function (x, y)
    {
        if ( (g_colour != 's') && (g_turn == g_colour) )
        {
            var closest = new Array();
    
            for ( var x = 0; x <= this.vCells; x += 1 )
            {
                for ( var y = 0; y <= this.hCells; y += 1 )
                {
                    xCoord = this.pos.x + x*this.cellWidth;
                    yCoord = this.pos.y + y*this.cellHeight;
    
                    distance = pointDistance(xCoord, yCoord, GameObjectManager.mousePos.x, GameObjectManager.mousePos.y)
    
                    if ( closest.length == 0 )
                    {
                        closest = [x, y, distance];
                    }
                    else if ( distance < closest[2] )
                    {
                        closest = [x, y, distance];
                    }
                }
            }
        
            //var text = closest[0] + ', ' + closest[1] + ' : ' + closest[2];
            //document.getElementById('debug2').innerHTML = text;

            if ( ! this.grid[closest[0]][closest[1]] )
            {
                // Set the stone on the grid for drawing
                this.grid[closest[0]][closest[1]] = g_colour;
                GameObjectManager.draw();
    
                // Send the stone placement to the server
                WebSocketsManager.send(g_gameID + ':' + g_playerID + ':' + 'stonePlace' + ':' + closest[0] + 'x' + closest[1] + 'x' + g_colour);
                
                // Change who's turn it is
                if (g_turn == 'w')
                {
                    g_turn = 'b';
                }
                else
                {
                    g_turn = 'w';
                }
            }
            
        }

        function pointDistance(x1, y1, x2, y2)
        {
            return Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1))
        }
    };

    /**
        Draw event for the game object
    */
    this.draw = function ()
    {
        // Draw the grid lines
        for ( var x = this.pos.x; x <= (this.hCells*this.cellWidth + this.pos.x); x += this.cellWidth )
        {
            g_backBufferContext2D.moveTo(x, this.pos.y);
            g_backBufferContext2D.lineTo(x, this.hCells*this.cellWidth + this.pos.y);
        }
        
        for ( var y = this.pos.y; y <= (this.vCells*this.cellHeight + this.pos.y); y += this.cellHeight )
        {
            g_backBufferContext2D.moveTo(this.pos.x, y);
            g_backBufferContext2D.lineTo(this.vCells*this.cellHeight + this.pos.x, y);
        }
        
        g_backBufferContext2D.strokeStyle = "#000";
        g_backBufferContext2D.stroke();
        
        // Draw the stones
        for ( var x = 0; x <= this.vCells; x += 1 )
        {
            for ( var y = 0; y <= this.hCells; y += 1 )
            {
                if ( this.grid[x][y] )
                {
                    if ( this.grid[x][y] == 'w' )
                    {
                        var stoneSprite = 0;
                    }
                    else if ( this.grid[x][y] == 'b' )
                    {
                        var stoneSprite = 1;
                    }
                    
                    g_backBufferContext2D.drawImage(
                        SpriteManager.gameSprites[stoneSprite],
                        this.pos.x + x*this.cellWidth - SpriteManager.gameSprites[stoneSprite].width/2,
                        this.pos.y + y*this.cellHeight - SpriteManager.gameSprites[stoneSprite].height/2
                    );
                }
            }
        }
    };
}
Grid.prototype = new GameObject;