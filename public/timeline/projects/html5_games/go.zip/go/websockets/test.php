#!/php -q
<?php  
// Run from command prompt > php -q pong.php
include "websocket.class.php";

// Extended basic WebSocket as ChatBot
class Test extends WebSocket
{
	var $x = 'unset';
	function process($user,$msg)
	{
		$this->say("< ".$msg);
		switch($msg){
		  case "set var" : $this->x = 'pie';                       break;
		  case "gimme var"    : $this->send($user->socket,$this->x);                         break;
		  case "hi player 2"  : $this->send($this->users[1]->socket,"player 1 says hi"); break;
		  case "age"   : $this->send($user->socket,"I am older than time itself");       break;
		  case "date"  : $this->send($user->socket,"today is ".date("Y.m.d"));           break;
		  case "time"  : $this->send($user->socket,"server time is ".date("H:i:s"));     break;
		  case "thanks": $this->send($user->socket,"you're welcome");                    break;
		  case "bye"   : $this->send($user->socket,"bye");                               break;
		  //default      : $this->send($user->socket,$msg." not understood");              break;
		}
	
	}
}

$master = new Test("localhost",12345);