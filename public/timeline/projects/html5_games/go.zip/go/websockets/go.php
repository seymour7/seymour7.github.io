#!/php -q
<?php  
// Run from command prompt > php -q pong.php
include "websocket.class.php";

// Extended basic WebSocket as Go
class Go extends WebSocket
{
	var $games = array();

	function process($user, $msg)
	{
		// Print all the received messages to the console
		$this->say("< ".$msg);

		// Split up the received message
		$msg = explode(":", $msg);
		$game = $msg[0];
		$player = $msg[1];
		$type = $msg[2];
		$data = $msg[3];

		// If the game doesn't exist, add it to the game list
		if ( ! array_key_exists($game, $this->games))
		{
			$this->games[$game] = array();
			$this->games[$game]['players'] = array(); // NEED TO REMOVE PLAYERS OFF THIS ARRAY ON DISCONNECT OR USE TRY EXC OR SUMTHING
			$this->games[$game]['grid'] = array();
			$this->games[$game]['chains'] = array();
		}
		
		// If the player doesn't exist, add him to the game
		if ( ! array_key_exists($player, $this->games[$game]['players']))
		{
			$this->games[$game]['players'][$player] = $user->socket;
		}
		
		// Reply with the player's side if registering
		if ($type == 'reg')
		{
			if (count($this->games[$game]['players']) == 1)
			{
				// Return white
				$this->send($user->socket, 'col:w');
				// Set turn to white
				$this->games[$game]['turn'] = 'w';
			}
			elseif (count($this->games[$game]['players']) == 2)
			{
				// Return black
				$this->send($user->socket, 'col:b');
				// Send who's turn it is
				$this->send($user->socket, 'turn:'.$this->games[$game]['turn']);
			}
			else
			{
				// Return spectator
				$this->send($user->socket, 'col:s');
				// Send who's turn it is
				$this->send($user->socket,'turn:'.$this->games[$game]['turn']);
			}
		}
		
		// Setup the blank grid
		if ($type == 'gridSize')
		{
			list($hCells, $vCells) = explode("x", $data);
			
			for ($x = 0; $x <= $vCells; $x++)
			{
				for ($y = 0; $y <= $hCells; $y++)
				{
					$this->games[$game]['grid'][$x][$y] = false; // or use array_fill()
				}
			}
			$this->say('! '.$hCells.'x'.$vCells.' grid created');
		}
		
		// Send the current grid state
		if ( $type == 'gridState' )
		{
			$grid = '';
			for ($x = 0; $x < count($this->games[$game]['grid']); $x++)
			{
				for ($y = 0; $y < count($this->games[$game]['grid'][$x]); $y++)
				{
					if ($this->games[$game]['grid'][$x][$y])
					{
						$grid .= $x.'-'.$y.'-'.$this->games[$game]['grid'][$x][$y].'-';
					}
				}
			}
			
			// Remove the last '-' from the string
			if ($grid != '')
			{
				$grid = substr($grid, 0, -1);
			}
			
			// Send the string containing the grid data
			$this->send($user->socket, 'gridState:'.$grid);
		}
		
		// Add the stones to the grid and send to other players
		if ($type == 'stonePlace')
		{
			list($closestX, $closestY, $colour) = explode("x", $data);
			
			// Activate the stone on the grid
			$this->games[$game]['grid'][$closestX][$closestY] = $colour;
			
			// Change the current player turn
			if ($this->games[$game]['turn'] == 'w')
			{
				$this->games[$game]['turn'] = 'b';
			}
			else
			{
				$this->games[$game]['turn'] = 'w';
			}
			
			// Send the new stone placement to all players, besides the one that just placed it
			foreach ($this->games[$game]['players'] as $plyrID => $plyr)
			{
				if ($player != $plyrID)
				{
					$this->send($plyr, 'newStone:'.$closestX.'x'.$closestY.'x'.$colour);
				}
			}
			
			// Add the new stone to a chain, or possibly create a new chain
			$this->processChainsForNewStone($game, $closestX, $closestY);
			
			// Script for printing the current chains
			/*$printstring = '';
			foreach ($this->games[$game]['chains'] as $chain)
			{
				foreach ($chain['vals'] as $xkey => $x)
				{
					foreach ($x as $ykey => $y)
					{
						if ($x && $y)
						{
							$printstring .= $xkey.'x'.$ykey.'-';
						}
					}
				}
				$printstring .= ' & col:'.$chain['col'].'
';
			}
			$this->say($printstring);*/
			
			// Find all the chains with no liberties and delete them
			$this->deleteChainsWithoutLiberties($game, $colour);
		}
	}
	
	/*
	-- Adds a newly placed stone to a chain of other stones
	*/
	function processChainsForNewStone($game, $x, $y)
	{
		$chainsAddedTo = array();
		// Stone to the left
		if ($x-1 >= 0)
		{
			$c = $this->addStoneToChain($game, $x, $y, $x-1, $y);
			if ($c !== FALSE)
			{
				if ( ! in_array($c, $chainsAddedTo))
				{
					array_push($chainsAddedTo, $c);
				}
			}
		}
		// Stone to the right
		if ($x+1 <= count($this->games[$game]['grid'])-1)
		{
			$c = $this->addStoneToChain($game, $x, $y, $x+1, $y);
			if ($c !== FALSE)
			{
				if ( ! in_array($c, $chainsAddedTo))
				{
					array_push($chainsAddedTo, $c);
				}
			}
		}
		// Stone above
		if ( $y-1 >= 0 )
		{
			$c = $this->addStoneToChain($game, $x, $y, $x, $y-1);
			if ($c !== FALSE)
			{
				if ( ! in_array($c, $chainsAddedTo))
				{
					array_push($chainsAddedTo, $c);
				}
			}
		}
		// Stone below
		if ( $y+1 <= count($this->games[$game]['grid'][0])-1 )
		{
			$c = $this->addStoneToChain($game, $x, $y, $x, $y+1);
			if ($c !== FALSE)
			{
				if ( ! in_array($c, $chainsAddedTo))
				{
					array_push($chainsAddedTo, $c);
				}
			}
		}
		
		// No chains found, start a new chain
		if (count($chainsAddedTo) == 0)
		{
			array_push($this->games[$game]['chains'], array(
				'vals' => array(
					$x => array(
						$y => TRUE)),
				'col' => $this->games[$game]['grid'][$x][$y]
			));
		}
		
		// Bond overlapping chains if more than 1 chain found
		if (count($chainsAddedTo) > 1)
		{
			for ($i = 1; $i < count($chainsAddedTo); $i++)
			{
				$this->bondChains($game, $chainsAddedTo[0], $chainsAddedTo[$i]);
			}
		}
		
	}
	
	/*
	-- Adds a newly placed stone to a chain of other stones
	*/
	function addStoneToChain($game, $x, $y, $nearbyX, $nearbyY)
	{
		// If the stone to the left exists and is the same colour
		if ($this->games[$game]['grid'][$nearbyX][$nearbyY] == $this->games[$game]['grid'][$x][$y])
		{
			// Find the correct chain to add the stone to
			$chainKey = $this->stoneExistsInChain($game, $nearbyX, $nearbyY);
			if ($chainKey !== FALSE)
			{
				// Chain detected - add stone to the chain
				$this->games[$game]['chains'][$chainKey]['vals'][$x][$y] = TRUE;
				return $chainKey;
			}
		}
		return FALSE;
	}
	
	/*
	-- Checks if a stone exists in any of the chains
	*/
	function stoneExistsInChain($game, $x, $y)
	{
		foreach ($this->games[$game]['chains'] as $chainKey => $chain)
		{
			if (isset($chain['vals'][$x][$y]))
			{
				if ($chain['vals'][$x][$y])
				{
					return $chainKey;
				}
			}
		}
		return FALSE;
	}
	
	/*
	-- Bonds 2 chains together
	*/
	function bondChains($game, $c1, $c2)
	{
		foreach ($this->games[$game]['chains'][$c2]['vals'] as $x => $xArray)
		{
			foreach ($xArray as $y => $yVal)
			{
				if ($yVal == TRUE)
				{
					if ( ! isset($this->games[$game]['chains'][$c1]['vals'][$x][$y]))
					{
						$this->games[$game]['chains'][$c1]['vals'][$x][$y] = TRUE;
						
					}
					elseif ( ! $this->games[$game]['chains'][$c1]['vals'][$x][$y])
					{
						$this->games[$game]['chains'][$c1]['vals'][$x][$y] = TRUE;
					}
				}
			}
		}
		// Remove the second chain
		unset($this->games[$game]['chains'][$c2]);
	}
	
	/*
	-- Finds the chains that have no liberties
	*/
	function deleteChainsWithoutLiberties($game, $colourPlaced)
	{
		// First sort the chains, so chains of the opposite colour are deleted first [#could be done more efficiently]
		/*$this->say('Unsorted:');
		foreach ($this->games[$game]['chains'] as $chain)
		{ $this->say($chain['col']); }*/
		foreach ($this->games[$game]['chains'] as $chainKey => $chain)
		{
			if ($chain['col'] != $colourPlaced)
			{
				// Remove the chain from the array
				unset($this->games[$game]['chains'][$chainKey]);
				// Add the chain to the end of the array (doesn't effect the current keys)
				array_push($this->games[$game]['chains'], $chain);
			}
		}
		array_reverse($this->games[$game]['chains']);
		/*$this->say('Sorted:');
		foreach ($this->games[$game]['chains'] as $chain)
		{ $this->say($chain['col']); }*/
		
		// Now search for liberties and handle chain deletion
		foreach ($this->games[$game]['chains'] as $chainKey => $chain)
		{
			$hasLiberties = FALSE;
			foreach ($chain['vals'] as $x => $xArray)
			{
				foreach ($xArray as $y => $yVal)
				{
					if ($yVal == TRUE)
					{
						// To the left
						if ( $x-1 >= 0 )
						{
							if ($this->games[$game]['grid'][$x-1][$y] == FALSE)
							{
								$hasLiberties = TRUE;
								break 2;
							}
						}
						// To the right
						if ( $x+1 <= count($this->games[$game]['grid'])-1 )
						{
							if ($this->games[$game]['grid'][$x+1][$y] == FALSE)
							{
								$hasLiberties = TRUE;
								break 2;
							}
						}
						// Above
						if ( $y-1 >= 0 )
						{
							if ($this->games[$game]['grid'][$x][$y-1] == FALSE)
							{
								$hasLiberties = TRUE;
								break 2;
							}
						}
						// Below
						if ( $y+1 <= count($this->games[$game]['grid'][0])-1 )
						{
							if ($this->games[$game]['grid'][$x][$y+1] == FALSE)
							{
								$hasLiberties = TRUE;
								break 2;
							}
						}
					}
				}
			}
			if ( ! $hasLiberties)
			{
				// Generate the delete string and remove stones from the server's grid
				$delString = '';
				foreach ($chain['vals'] as $x => $xArray)
				{
					foreach ($xArray as $y => $yVal)
					{
						if ($yVal == TRUE)
						{
							$delString .= $x.'x'.$y.'x';
							$this->games[$game]['grid'][$x][$y] = FALSE; //NEED TO DEL CHAINS OF OTHER COLOUR FIRST OR SUMMIN
						}
					}
				}
				
				// Remove the chain from the chain list
				unset($this->games[$game]['chains'][$chainKey]);

				// Send the string of all stones to delete to all players
				if ($delString != '')
				{
					foreach ($this->games[$game]['players'] as $plyr)
					{
						// Send message to delete chains with no liberties 
						$this->send($plyr, 'delStones:'.substr($delString, 0, -1));
					}
				}
			}
		}
		return TRUE;
	}
}

$master = new Go("localhost",12345);