////////////////////////////////////
//        GLOBAL VARIABLES        //
////////////////////////////////////

/** Target frames per second  
    Type: Integer
*/
var FPS = 60;
/** Time between frames 
    Type: Integer
*/
var MILLISECONDS_BETWEEN_FRAMES = (1 / FPS) * 1000;
/** A reference to the canvas element  
    Type: HTMLCanvasElement
*/
var g_canvas = null;
/** A reference to the 2D context of the canvas element
    Type: CanvasRenderingContext2D
*/
var g_context2D = null;
/** A global reference to the in-memory canvas used as a back buffer
    Type: HTMLCanvasElement
*/
var g_backBuffer = null;
/** A global reference to the backbuffer 2D context
    Type: CanvasRenderingContext2D
*/
var g_backBufferContext2D = null;


////////////////////////////////////
//    APPLICATION ENTRY POINT     //
////////////////////////////////////

/**
    The entry point of the application is set to the init function
*/
window.onload = init;

/**
    Function that gets this party started
*/
function init()
{    
    // Assign references to the canvas elements and later, their 2D contexts
    g_canvas = document.getElementById('canvas');

    // If the g_canvas.getContext function does not exist it is a safe bet that
    // the current browser does not support the canvas element
    if (g_canvas.getContext)
    {
        g_context2D = g_canvas.getContext('2d');
        g_backBuffer = document.createElement('canvas');
        g_backBuffer.width = g_canvas.width;
        g_backBuffer.height = g_canvas.height;
        g_backBufferContext2D = g_backBuffer.getContext('2d');

        // Create the Sprite Manager
        SpriteManager.startupSpriteManager();
    }
}


////////////////////////////////////
//        SPRITE MANAGMENT        //
////////////////////////////////////

/**
    A manager for all the sprites used in the game
*/
var SpriteManager =
{
    /** An array of sprite sources to load
        Type: Array
    */
    spriteSources: [
        'sprites/ball.png',
        'sprites/paddle.png'
    ],
    /** An array of sprites
        Type: Array
    */
    gameSprites: new Array(),
    /** The ID for the interval which displays the loading screen so we can clear it afterwards
        Type: ID
    */
    loadScrIntervalId: null,
    /** True if the sprites supplied to the sprite manager are all loaded, false otherwise
        Type: Boolean
    */
    spritesLoaded: false,
    
    /**
        Initialises the Sprite Manager
    */
    startupSpriteManager: function ()
    {
        for (var i = 0; i < this.spriteSources.length; i++)
        {
            // Create new Image object and add to array
            this.gameSprites[i] = new Image;
            
            // Assign the .src property of the Image object so they start loading
            this.gameSprites[i].src = this.spriteSources[i];
            
            // Display show the loading screen while the sprites load
            this.loadScrIntervalId = setInterval(function(){SpriteManager.displayLoadingScreen();}, MILLISECONDS_BETWEEN_FRAMES);
        }
    },
    
    /**
        Starts the sprite manager
    */
    displayLoadingScreen: function ()
    {
        if (!this.spritesLoaded)
        {
            var numLoaded = 0;
            for (var i in this.gameSprites)
            {
                if (this.gameSprites[i].complete)
                    numLoaded++;
            }

            if (numLoaded == this.spriteSources.length)
            {
                this.spritesLoaded = true;

                // Create the WebSockets Manager
                WebSocketsManager.startupWebSocketsManager();
                
                // Create the GameObjectManager
                GameObjectManager.startupGameObjectManager();
                
                // Create the Room Manager
                //RoomManager.startupRoomManager();
            }
            else
            {
                // Clear the drawing context
                g_context2D.clearRect(0, 0, g_canvas.width, g_canvas.height);
                
                // Draw a rectangular loading bar
                g_context2D.fillStyle = "#FFFFFF";
                g_context2D.fillRect(g_canvas.width/2-numLoaded*30, g_canvas.height/2-10, numLoaded*60, 20);
            }
        }
        else
        {
            // Stop trying to draw the loading screen
            clearInterval(this.loadScrIntervalId);
        }
    }
};


////////////////////////////////////
//      WEBSOCKETS MANAGMENT      //
////////////////////////////////////

/**
    A manager for using WebSockets
*/
var WebSocketsManager =
{
    /** The URL to the WebSockets server
        Type: String
    */
    host: "ws://localhost:12345/pong/websocket/pong.php",
    /** The ID for the interval which displays the loading screen so we can clear it afterwards
        Type: Object
    */
    socket: null,

    /**
        Initialises the WebSockets Manager
    */
    startupWebSocketsManager: function ()
    {
        if (!("WebSocket" in window))
        {
            // The user does not have WebSockets
            this.log('Browser does not support WebSockets')
        }
        else
        {  
            // The user has WebSockets  
            try
            {
                this.socket = new WebSocket(this.host);
                this.log('WebSocket - status ' + this.socket.readyState);
                this.socket.onopen = function(msg)
                {
                    WebSocketsManager.log("Welcome - status " + this.readyState);
                    WebSocketsManager.send('3');
                };
                this.socket.onclose   = function(msg){ WebSocketsManager.log("Disconnected - status " + this.readyState); };
                this.socket.onmessage = function(msg)
                {
                    WebSocketsManager.log("Received: " + msg.data);
                    if ( msg.data.substr(0, 1) == '3')
                    {
                        window.g_player = msg.data.substr(1, 1);
                        RoomManager.startupRoomManager();
                    }
                    else
                    {
                        // Run the multiplayer event of all the game objects
                        for (x in GameObjectManager.gameObjects)
                        {
                            if (GameObjectManager.gameObjects[x].multiplayer)
                            {
                                GameObjectManager.gameObjects[x].multiplayer(msg.data);
                            }
                        }
                    }
                };
            }
            catch(ex){ this.log(ex); }
        }  
    },

    /**
        Sends messages to the WebSockets server
        Param: msg The message to send
    */
    send: function (/**String*/ msg)
    {
        try
        {
            this.socket.send(msg); // only send when connected to server
            this.log('Sent: ' + msg);
        }
        catch(ex){ this.log(ex); }
    },

    /**
        Logs messages for the user
        Param: msg The message to log
    */
    log: function (/**String*/ msg)
    {
        document.getElementById("scktlog").innerHTML = "<br>" + msg + document.getElementById("scktlog").innerHTML;
    }
};


////////////////////////////////////
//     GAME OBJECT MANAGMENT      //
////////////////////////////////////

/**
    A manager for all the objects in the game
*/
var GameObjectManager =
{
    /** An array of game objects 
        Type: Array
    */
    gameObjects: new Array(),
    /** Array for all the keyboard keys that are currently pressed
        Type: Array
    */
    keysDown: new Array(),
    
    /**
        Initialises the Game Object Manager
    */
    startupGameObjectManager: function ()
    {
        // Use setInterval to call the draw function
        setInterval(function(){GameObjectManager.draw();}, MILLISECONDS_BETWEEN_FRAMES);
        
        // Watch for keyboard events
        document.onkeydown = function(event){GameObjectManager.keyDown(event);}
        document.onkeyup = function(event){GameObjectManager.keyUp(event);}
    },
    
    /**
        The render loop
    */
    draw: function ()
    {
        // Clear the back buffer drawing context
        g_backBufferContext2D.clearRect(0, 0, g_backBuffer.width, g_backBuffer.height);

        // First, run the keyboard event of all the game objects - probz shouldnt call'this method 'draw' then
        for (x in this.gameObjects)
        {
            if (this.gameObjects[x].keyboard)
            {
                this.gameObjects[x].keyboard();
            }
        }

        // Second, run the step event of all the game objects
        for (x in this.gameObjects)
        {
            if (this.gameObjects[x].step)
            {
                this.gameObjects[x].step();
            }
        }

        // Third, draw the game objects
        for (x in this.gameObjects)
        {
            if (this.gameObjects[x].draw)
            {
                this.gameObjects[x].draw();
            }
        }
        
        // Clear the displayed canvas's drawing context
        //g_context2D.clearRect(0, 0, g_canvas.width, g_canvas.height);
        g_context2D.clearRect(12, 0, 2, g_canvas.height);
        g_context2D.clearRect(586, 0, 2, g_canvas.height);
        
        // Now copy the back buffer to the displayed canvas
        g_context2D.drawImage(g_backBuffer, 0, 0);
    },
    
    /**
        Works with keyUp to maintain the array of all keyboard keys that are currently pressed
        Param: event
    */
    keyDown: function(event)
    {
        if (!this.keysDown[event.keyCode])
        {
            this.keysDown[event.keyCode] = true;
        }
    },

    /**
        Works with keyDown to maintain the array of all keyboard keys that are currently pressed
        Param: event
    */
    keyUp: function(event)
    {
        if (this.keysDown[event.keyCode])
        {
            this.keysDown[event.keyCode] = false;
        }
    }
};


////////////////////////////////////
//         ROOM MANAGMENT         //
////////////////////////////////////

/**
    A manager for the room(s - in the future) in the game
*/
var RoomManager =
{
    /**
        Initialises the Room Manager
    */
    startupRoomManager: function ()
    {
        window.obj_lPaddle = new Paddle().startupGameObject(1, 12, g_canvas.height/2);
        window.obj_rPaddle = new Paddle().startupGameObject(1, (g_canvas.width - 1 - 12) - (SpriteManager.gameSprites[1].width - 1), g_canvas.height/2);
        window.obj_ball = new Ball().startupGameObject(0, g_canvas.width/2+120, g_canvas.height/2);
        
        if ( g_player == 'l' )
        {
            obj_lPaddle.player = true;
        }
        else if ( g_player == 'r' )
        {
            obj_rPaddle.player = true;
        }
        WebSocketsManager.send('0'+g_player);
    }
};


////////////////////////////////////
//     GAME OBJECT BASE CLASS     //
////////////////////////////////////

/**
    The base class for all objects that appear in the game
    Note: Couldn't use JSON formatting because of inheritance issues
*/
function GameObject ()
{
    /** The index number of the sprite to use for this object
        Type: Integer
    */
    this.spriteIndex = null;
    /** The position on the X axis
        Type: Integer
    */
    this.x = 0;
    /** The position on the Y axis
        Type: Integer
    */
    this.y = 0;
    
    /**
        Initialises the game object and adds it to the game object list
        Param: spriteIndex The index number of the sprite to use for this object
        Param: x The position on the X axis
        Param: y The position on the Y axis
    */
    this.startupGameObject = function (/**Integer*/ spriteIndex, /**Integer*/ x, /**Integer*/ y)
    {
        // Add this game object to the game object list
        GameObjectManager.gameObjects.push(this);
        
        // Assign local variables
        this.spriteIndex = spriteIndex;
        this.x = x;
        this.y = y;
        
        // Run the create event in the object
        if (this.create)
        {
            this.create();
        }
        
        // Return a reference to this object
        return this;
    };
    
    /**
        Draws this game object to the back buffer
    */
    this.draw = function ()
    {
        g_backBufferContext2D.drawImage(
            SpriteManager.gameSprites[this.spriteIndex],
            /*Math.round*/(this.x), //http://stackoverflow.com/questions/4437428/html5-canvas-avoid-drawing-half-pixel-for-improved-speed
            /*Math.round*/(this.y)
        );
    };
}


////////////////////////////////////
//          GAME OBJECTS          //
////////////////////////////////////

/**
    The paddles used by the players
    Note: Couldn't use JSON formatting because of inheritance issues
*/
function Paddle ()
{
    /** The speed of the paddle in pixels per frame
        Type: Integer
    */
    this.speed = 5;
    /** True if this is the paddle the player controls
        Type: Boolean
    */
    this.player = false;
    /** The ID of this paddle (left or right)
        Type: String
    */
    this.padId = null;
    
    /**
        Create event for the game object
    */
    this.create = function ()
    {
        /*if ( typeof(obj_lPaddle) == 'undefined' )
        {
            this.padId = 'l';
        }
        else
        {
            this.padId = 'r';
        }*/
    };
    
    /**
        Keyboard event for the game object
    */
    this.keyboard = function ()
    {
        // Up
        if (GameObjectManager.keysDown[38] == true)
        {
            if ( this.player )
            {
                if ( (this.y - this.speed) >= 0 )
                    this.y -= this.speed;
                else // Flush nicely with the border
                    this.y = 0;
    
                WebSocketsManager.send('1' + this.y.toString());
            }
        }
        
        // Down
        if (GameObjectManager.keysDown[40] == true)
        {
            if ( this.player )
            {
                if ( (this.y + SpriteManager.gameSprites[this.spriteIndex].height + this.speed) <= g_canvas.height )
                    this.y += this.speed;
                else // Flush nicely with the border
                    this.y = g_canvas.height - SpriteManager.gameSprites[this.spriteIndex].height;
    
                WebSocketsManager.send('1' + this.y.toString());
            }
        }
    };
    
    /**
        Multiplayer event for the game object
    */
    this.multiplayer = function (msg)
    {
        
    };
}
Paddle.prototype = new GameObject;

/**
    The ball that bounces around
    Note: Couldn't use JSON formatting because of inheritance issues
*/
function Ball ()
{
    /** The speed of the ball in pixels per frame
        Type: Integer
    */
    this.speed = 3;
    /** The direction of the ball in radians clockwise from east
        Type: Integer
    */
    this.direction = Math.PI*1.25;
    
    /**
        Step event for the game object
    */
    this.step = function ()
    {
        // Get the position of the ball in the next frame
        var futPos = [this.x + this.speed * Math.cos(this.direction), this.y + this.speed * Math.sin(this.direction)];
        
        // If the ball is going to pass the WALL, rather bounce
        var c;
        if ( c = this.wallCollide(futPos[1], SpriteManager.gameSprites[this.spriteIndex].height) )
        {
            // Get the equations of the walls
            if (c == 1)
            {
                // Get Y value of the top wall
                var wallY = 0;
                // Distance is 0 cause top of object bounces off wall
                var boundBoxBot = 0;
            }
            else
            {
                // Get Y value of the bottom wall
                var wallY = g_canvas.height - 1;
                // Distance to the bottom of object as the bottom bounces off the wall
                var boundBoxBot = SpriteManager.gameSprites[this.spriteIndex].height - 1;
                futPos[1] += boundBoxBot;
            }
            
            // Get the coordinate of the intersection with the wall
            intersectCoord = this.intersection( [this.x, this.y + boundBoxBot, futPos], 0, wallY );
            
            // Correct the intersection coordinates for calculating future pos
            intersectCoord[1] -= boundBoxBot;
            
            // Change the direction (must be before calcuating the new position)
            this.direction = Math.PI*2 - this.direction;
            
            // Calculate the new position of the bounced ball
            futPos = this.bounce(intersectCoord);
        }
        
        // If the ball is going to pass the PADDLE, rather bounce
        var p;
        if ( p = this.paddleCollide(futPos) )
        {
            // Get the percent down the paddle where the ball collided (0.0 to 1.0)
            if ( p[1] == 0 )
            {
                var portionDownPaddle = (p[0][1] - (obj_lPaddle.y - SpriteManager.gameSprites[obj_ball.spriteIndex].height)) / 
                (SpriteManager.gameSprites[obj_lPaddle.spriteIndex].height + SpriteManager.gameSprites[obj_ball.spriteIndex].height);
            }
            else
            {
                var portionDownPaddle = (p[0][1] - (obj_rPaddle.y - SpriteManager.gameSprites[obj_ball.spriteIndex].height)) / 
                (SpriteManager.gameSprites[obj_rPaddle.spriteIndex].height + SpriteManager.gameSprites[obj_ball.spriteIndex].height);
            }


            var text = '% down paddle: ' + portionDownPaddle;     
            document.getElementById('debug').innerHTML = text;


            // Change the direction (must be before new pos calc)
            if ( portionDownPaddle > 0.5 )
            {
                this.direction = ((portionDownPaddle - 0.5)/0.5) * Math.PI/2 * 0.9;
                // Flip dir if hitting the right paddle
                if ( p[1] == 1 )
                {
                    this.direction = Math.PI - this.direction;
                }
            }
            else
            {
                this.direction = Math.PI*2 - ((0.5 - portionDownPaddle)/0.5) * Math.PI/2 * 0.9;
                // Flip dir if hitting the right paddle
                if ( p[1] == 1 )
                {
                    this.direction = Math.PI + (Math.PI*2 - this.direction);
                }
            }

            // Calculate the new position of the bounced ball
            futPos = this.bounce(p[0]);
        }

        // Move the ball, eventually
        this.x = futPos[0];
        this.y = futPos[1];


        /*var text = '';     
        document.getElementById('debug').innerHTML = text;*/
    };
    
    /**
        Custom method - Determines if that ball will collide with a wall in the next step
        Param: futureY The y value for the next step in the ball's motion
        Param: ballHeight The height of the ball that may collide with a wall
    */
    this.wallCollide = function (futureY, ballHeight)
    {
        if ( futureY < 0 )
        {
            // Collides with top wall
            return 1;
        }
        else if ( futureY + ballHeight - 1 > g_canvas.height - 1 )
        {
            // Collides with bottom wall
            return 2;
        }
        else
        {
            // Does not collide with a wall
            return false;
        }
    };

    /**
        Custom method - Determines if that ball will collide with a paddle in the next step
        Param: futPos The position of the ball in the next frame
    */
    this.paddleCollide = function (futPos)
    {
        if ( (futPos[0] < obj_lPaddle.x + SpriteManager.gameSprites[obj_lPaddle.spriteIndex].width) && (obj_ball.x >= obj_lPaddle.x + SpriteManager.gameSprites[obj_lPaddle.spriteIndex].width) )
        {
            // Collides with left paddle
            p = this.intersection( [obj_ball.x, obj_ball.y, futPos], 1, obj_lPaddle.x + SpriteManager.gameSprites[obj_lPaddle.spriteIndex].width );

            if ( (p[1] >= obj_lPaddle.y) && (p[1] < obj_lPaddle.y + SpriteManager.gameSprites[obj_lPaddle.spriteIndex].height) )
            {
                // Top left pixel of ball hit the paddle
                return [p, 0];
            }
            else if ( (p[1] < obj_lPaddle.y) && (p[1] + SpriteManager.gameSprites[obj_ball.spriteIndex].height > obj_lPaddle.y) )
            {
                // Ball just nicked the top of the paddle (top left missed, bottom left hit)
                return [p, 0];
            }
            else
            {
                // Ball just plain old missed the paddle
                return 0;
            }
        }
        else if ( (futPos[0] + SpriteManager.gameSprites[obj_ball.spriteIndex].width > obj_rPaddle.x) && (obj_ball.x + SpriteManager.gameSprites[obj_ball.spriteIndex].width <= obj_rPaddle.x) )
        {
            // Distance to right of ball as ball bounces on right side
            var boundBoxRight = SpriteManager.gameSprites[obj_ball.spriteIndex].width - 1;
            var futPosRight = [futPos[0] + boundBoxRight, futPos[1]]; // Because passing a variable in an object passes it by reference, not by value
            
            // Collides with right paddle
            p = this.intersection( [obj_ball.x + boundBoxRight, obj_ball.y, futPosRight], 1, obj_rPaddle.x - 1 );
            
            // Move focus back to top left pixel
            p[0] -= boundBoxRight;

            if ( (p[1] >= obj_rPaddle.y) && (p[1] < obj_rPaddle.y + SpriteManager.gameSprites[obj_rPaddle.spriteIndex].height) )
            {
                // Top right pixel of ball hit the paddle
                return [p, 1];
                
            }
            else if ( (p[1] < obj_rPaddle.y) && (p[1] + SpriteManager.gameSprites[obj_ball.spriteIndex].height > obj_rPaddle.y) )
            {
                // Ball just nicked the top of the paddle (top right missed, bottom right hit)
                return [p, 1];
                
            }
            else
            {
                // Ball just plain old missed the paddle
                return 0;
            }
        }
        else
        {
            // Does not collide with a paddle, not even in the area
            return 0;
        }
    };

    /**
        Custom method - Calculates the intersection of a slanted line with vert or hor line
        Param: line1 The slanted line
        Param: type 0 if horizontal, 1 if vertical
        Param: line2 The y or x value of the line
    */
    this.intersection = function (/**Array*/ line1, /**Integer*/ type, /**Integer*/ line2)
    {
        // Line 1 (x1,y1) to (x2,y2)
        // This is usually the ball's trajectory
        var x1 = line1[0];
        var y1 = line1[1];
        var x2 = line1[2][0];
        var y2 = line1[2][1];

        if (type == 0)
        {
            // Line 2
            // This is the horizontal wall
            var y3 = line2;
    
            // Calculate the intersection
            var ixtop = x1*(y2-y3) + x2*(y3-y1);
            var ixbot = y2 - y1;
            var ix = ixtop/ixbot;
    
            var iy = y3;
        }
        else
        {
            // Line 2
            // This is the vertical paddle line
            var x3 = line2;
    
            // Calculate the intersection
            var iytop = (x1*y2 - x2*y1) + (y1-y2)*x3;
            var iybot = x1 - x2;
            var iy = iytop/iybot;
    
            var ix = x3;
        }

        // Return the intersection coordinates
        return [ix, iy];
    };
    
    /**
        Custom method - Determines the new position of the ball after it has bounced
        Param: intersectCoord The position where the ball bounces
    */
    this.bounce = function (/**Array*/ intersectCoord)
    {
        // Get the remaining distance to travel after the bounce
        var s = this.speed - Math.sqrt( Math.pow((this.x - intersectCoord[0]), 2) + Math.pow((this.y - intersectCoord[1]), 2) );

        return [intersectCoord[0] + s * Math.cos(this.direction), intersectCoord[1] + s * Math.sin(this.direction)];
    };
}
Ball.prototype = new GameObject;