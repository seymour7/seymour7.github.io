#!/php -q
<?php  
// Run from command prompt > php -q pong.php
include "websocket.class.php";

// Extended basic WebSocket as ChatBot
class Pong extends WebSocket
{
	var $padId = null;
	var $otherPadId = null;

	function process($user,$msg)
	{
		$this->say("< ".$msg);
		switch($msg){
		  case "hello" : $this->send($user->socket,"hello human");                       break;
		  case "hi server"    : $this->send($user->socket,"sup client");                         break;
		  case "name"  : $this->send($user->socket,"my name is Multivac, silly I know"); break;
		  case "age"   : $this->send($user->socket,"I am older than time itself");       break;
		  case "date"  : $this->send($user->socket,"today is ".date("Y.m.d"));           break;
		  case "time"  : $this->send($user->socket,"server time is ".date("H:i:s"));     break;
		  case "thanks": $this->send($user->socket,"you're welcome");                    break;
		  case "bye"   : $this->send($user->socket,"bye");                               break;
		  //default      : $this->send($user->socket,$msg." not understood");              break;
		}
	
		if ( substr($msg, 0, 1) == '0' )
		{
			$this->padId = substr($msg, 1, 1);
			
			if ($this->padId == 'l')
			{
				$this->otherPadId = 'r';
			}
			else
			{
				$this->otherPadId = 'l';
			}
			
			$con = mysql_connect("localhost","root","");
			if (!$con)
			  {
			  die('Could not connect: ' . mysql_error());
			  }

			mysql_select_db("pong_db", $con);

			mysql_query("INSERT INTO pong (id, y) VALUES ('".$this->padId."', '0')");

			mysql_close($con);
		}
		
		if ( substr($msg, 0, 1) == '1' )
		{
			$y = substr($msg, 1);

			$con = mysql_connect("localhost","root","");
			if (!$con)
			  {
			  die('Could not connect: ' . mysql_error());
			  }
	
			mysql_select_db("pong_db", $con);

			mysql_query("UPDATE pong SET y='".$y."' where id='".$this->padId."'");
	
			mysql_close($con);
		}
		
		if ( substr($msg, 0, 1) == '3' )
		{
			$con = mysql_connect("localhost","root","");
			if (!$con)
			  {
			  die('Could not connect: ' . mysql_error());
			  }

			mysql_select_db("pong_db", $con);

			if( mysql_num_rows(mysql_query("SELECT id FROM pong WHERE id='l'")) )
			{
				$this->send($user->socket,"3r");
			}
			else if( mysql_num_rows(mysql_query("SELECT id FROM pong WHERE id='r'")) )
			{
				$this->send($user->socket,"3s");
			}
			else
			{
				$this->send($user->socket,"3l");
			}

			mysql_close($con);
		}

	}
}

$master = new Pong("localhost",12345);