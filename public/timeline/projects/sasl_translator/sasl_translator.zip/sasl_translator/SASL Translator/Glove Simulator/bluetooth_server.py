# Bluetooth glove simulator

from bluetooth import *
import csv
import time

# Create the Bluetooth socket
server_sock = BluetoothSocket( RFCOMM )
server_sock.bind(("",PORT_ANY))
server_sock.listen(1)

# Get the socket port
port = server_sock.getsockname()[1]

# Set UUID
uuid = "00001101-0000-1000-8000-00805f9b34fb"

# Allow device to connect to socket
advertise_service( server_sock,
                   "GloveServer",
                   service_id = uuid,
                   service_classes = [ uuid, SERIAL_PORT_CLASS ],
                   profiles = [ SERIAL_PORT_PROFILE ],
                    )
                   
print("Waiting for connection on RFCOMM channel %d" % port)

# Accept incoming connection
client_sock, client_info = server_sock.accept()
print("Accepted connection from ", client_info)

# Send glove data
while True:
    with open('test_large_input_random.csv', 'rb') as f:
        reader = csv.reader(f)
        for row in reader:
            temp = ",".join(row)
            print temp
            print "-------------------"
            client_sock.send(temp)
            time.sleep(1)

print("Disconnected")

client_sock.close()
server_sock.close()
