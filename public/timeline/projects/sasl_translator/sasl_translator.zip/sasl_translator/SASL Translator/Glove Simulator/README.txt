This Bluetooth glove simulator requires PyBluez.
https://code.google.com/p/pybluez/

It was successfully tested with PyBluez version 0.2 for
Python 2.7 on Microsoft Windows 7.

Note: The Python 2.7 version of PyBluez required that the 32 bit
      version of Python 2.7 was installed, and would not work
      using the 64 bit version of Python 2.7.