package com.example.sasltranslator;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.encog.ml.data.MLData;
import org.encog.ml.data.basic.BasicMLData;
import org.encog.ml.svm.SVM;
import org.encog.persist.EncogDirectoryPersistence;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Shader.TileMode;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This is the main activity that is created when the app is launched
 */
public class MainActivity extends Activity {
	// Debugging
    private static final String TAG = "MainActivity";
    private static final boolean D = true;
    
    // Message types sent from the BluetoothGloveService Handler
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;
    public static final int MESSAGE_CONN_FAIL = 6;
    public static final int MESSAGE_CONN_LOST = 7;
    
    // Key names received from the BluetoothGloveService Handler
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";
    
	// Intent request codes
	private static final int REQUEST_ENABLE_BT = 1;
	private static final int REQUEST_CONNECT_DEVICE = 2;
	
	// Layout ViewGroups
	private Menu mMenu;
	
	// Name of the connected device
    private String mConnectedDeviceName = null;
    // Array adapter for the glove data thread
    private ArrayAdapter<String> mGloveDataArrayAdapter;
	// Local Bluetooth adapter
	private BluetoothAdapter mBluetoothAdapter = null;
	// Member object for the glove services
    private BluetoothGloveService mGloveService = null;
	// True if text-to-speech is muted
	private boolean mMuted = false;
	// True if the glove is connected via Bluetooth
	private boolean mGloveConnected = false;
	
	// Stores the latest data received form the glove
	private double[] mLatestData = {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	
	// The support vector machine
	private SVM svm;
	
	// Used to store/retrieve preferences
	private SharedPreferences sharedPrefs;
	
	// Maps class numbers into their characters
	private Map<Integer, String> classMap = new HashMap<Integer, String>();
	
	// Text to Speech object
	TextToSpeech ttsObj;
	
	// Called when the activity is first created
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(D) Log.e(TAG, "+++ ON CREATE +++");
		
		// Set up the window layout
		setContentView(R.layout.activity_main);
		
		// Set default settings from the layout file (doesn't override settings)
		PreferenceManager.setDefaultValues(this, R.layout.activity_settings, false);
		
		// Get shared preferences manager
		sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
		
		// Get local Bluetooth adapter
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		
		// Update the instructions
		TextView t = (TextView)findViewById(R.id.letter);
		t.setVisibility(View.GONE);
		t = (TextView)findViewById(R.id.instructions);
		Typeface font = Typeface.createFromAsset(getAssets(), "ThrowMyHandsUpintheAir.ttf");
		t.setTypeface(font);
		t.setTextSize(30);
		
		// Format the letter history bar
		t = (TextView)findViewById(R.id.letterHistory);
		Shader textShader=new LinearGradient(0, 0, 420, 0,
		        new int[]{Color.TRANSPARENT,Color.GRAY},
		        new float[]{0, 1}, TileMode.CLAMP);
		t.getPaint().setShader(textShader);
		
		// Class mapping
        classMap.put(1, "A"); classMap.put(16, "Q");
        classMap.put(2, "B"); classMap.put(17, "R");
        classMap.put(3, "C"); classMap.put(18, "S");
        classMap.put(4, "D"); classMap.put(19, "T");
        classMap.put(5, "E"); classMap.put(20, "U");
        classMap.put(6, "F"); classMap.put(21, "V");
        classMap.put(7, "G"); classMap.put(22, "W");
        classMap.put(8, "H"); classMap.put(23, "X");
        classMap.put(9, "I"); classMap.put(24, "Y");
        classMap.put(10,"K"); classMap.put(25, "1");
        classMap.put(11,"L"); classMap.put(26, "3"); 
        classMap.put(12,"M"); classMap.put(27, "4");
        classMap.put(13,"N"); classMap.put(28, "5");
        classMap.put(14,"O"); classMap.put(29, "7");
        classMap.put(15,"P"); classMap.put(30, "8");
                              classMap.put(31, "9");
		
	}
	
	// Called when the activity is becoming visible to the user
	@Override
    public void onStart() {
        super.onStart();
        if(D) Log.e(TAG, "++ ON START ++");
	}
	
	// Called when the activity will start interacting with the user
    @Override
    public synchronized void onResume() {
    	
    	// Instantiate the TTS object
		ttsObj = new TextToSpeech(getApplicationContext(), 
		new TextToSpeech.OnInitListener() {
			@Override
			public void onInit(int status)
			{
				if(status != TextToSpeech.ERROR)
				{
					int result = ttsObj.setLanguage(Locale.UK);

			        if (result == TextToSpeech.LANG_MISSING_DATA
			                || result == TextToSpeech.LANG_NOT_SUPPORTED) {
			        	if(D) Log.e(TAG, "TTS This Language is not supported");
			        }
				}
				else
				{
					if(D) Log.e(TAG, "TTS Initilization Failed!");
			    }
		    }
		});
		
		// Check if mute was changed in preferences
		setMuted(sharedPrefs.getBoolean("pref_key_mute", true));
    			
        super.onResume();
        if(D) Log.e(TAG, "+ ON RESUME +");
    }
    
    // Called when the system is about to start resuming a previous activity
    @Override
    public synchronized void onPause() {
    	
    	// Destroy the TTS object
    	if (ttsObj !=null)
    	{
    		ttsObj.stop();
    		ttsObj.shutdown();
        }
    	
        super.onPause();
        if(D) Log.e(TAG, "- ON PAUSE -");
    }
     // Called when the activity is no longer visible to the user, because another activity has been resumed and is covering this one
    @Override
    public void onStop() {
        super.onStop();
        if(D) Log.e(TAG, "-- ON STOP --");
    }
    
    // The final call you receive before your activity is destroyed
    @Override
    public void onDestroy() {
        super.onDestroy();
        if(D) Log.e(TAG, "--- ON DESTROY ---");
    }
    
    // The Handler that gets information back from the BluetoothGloveService
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
            case MESSAGE_STATE_CHANGE:
                if(D) Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
                switch (msg.arg1) {
                case BluetoothGloveService.STATE_CONNECTED:
                    gloveConnected();
                    break;
                case BluetoothGloveService.STATE_CONNECTING:
                	gloveConnecting();
                    break;
                case BluetoothGloveService.STATE_NONE:
                	gloveDisconnected();
                    break;
                }
                break;
            case MESSAGE_CONN_FAIL:
            	gloveConnFailed();
            	break;
            case MESSAGE_CONN_LOST:
            	gloveConnLost();
            	break;
            case MESSAGE_READ:
            	ArrayList<String> datRow = new ArrayList<String>((ArrayList<String>) msg.obj);
        		// Don't do calibration
                for (int i=0; i<datRow.size(); i++) {
                	Double val = Double.parseDouble(datRow.get(i));
                	mLatestData[i] = val;
                }
                break;
            case MESSAGE_DEVICE_NAME:
                // Save the connected device's name
                mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
                Toast.makeText(getApplicationContext(), "Connected to "
                               + mConnectedDeviceName, Toast.LENGTH_SHORT).show();
                break;
            case MESSAGE_TOAST:
                Toast.makeText(getApplicationContext(), msg.getData().getString(TOAST),
                               Toast.LENGTH_SHORT).show();
                break;
            }
        }
    };
	
    // Handles the results from activities
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case REQUEST_ENABLE_BT:
	        // Make sure the Bluetooth connect request was successful
	        if (resultCode == RESULT_OK) {
	            // Bluetooth was successfully enabled
	        	displayDeviceList();
	        } else {
	        	// Bluetooth was not enabled
	        	Toast.makeText(getApplicationContext(),"Bluetooth needs to be enable to connect a glove",Toast.LENGTH_LONG).show();//TODO: use R.string.bt_not_enabled_leaving
	        }
	        break;
		case REQUEST_CONNECT_DEVICE:
			// When DeviceListActivity returns with a device to connect
            if (resultCode == Activity.RESULT_OK) {
                // Get the device MAC address
                String address = data.getExtras().getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
                // Get the BLuetoothDevice object
                BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
                // Attempt to connect to the device
                Singleton.getBGS().connect(device);
            }			
		}
	}
	
	// Called when the user clicks the Mute button
	public void actVoice(View view) {
			    
	    ImageButton voiceBtn = (ImageButton)findViewById(R.id.voice_button);
	    if (mMuted == false) {
	    	setMuted(true);
	    } else {
	    	setMuted(false);
	    }
	    
	    Editor editor = sharedPrefs.edit();
    	editor.putBoolean("pref_key_mute", mMuted);
    	editor.commit();
	}
	
	// Sets the application muted or not muted
	private void setMuted(boolean b) {
		ImageButton voiceBtn = (ImageButton)findViewById(R.id.voice_button);
		if (b == true) {
			voiceBtn.setImageResource(R.drawable.ic_action_volume_muted);
		    mMuted = true;
		}
		else {
	    	voiceBtn.setImageResource(R.drawable.ic_action_volume_on);
	    	mMuted = false;
	    }
	}
	
	// Called when the user clicks the Translate button
	public void doTranslate(View view) {
		
		if (mGloveConnected == true) {
			
			double[] inData = mLatestData;
			
			if (sharedPrefs.getBoolean("pref_calib_enabled", false)) {
        		// Do calibration
				inData = calibrateData(inData);
        	}

			// Get output of SVM
			BasicMLData input = new BasicMLData(inData);
		    MLData output = svm.compute(input);
		    
		    // Update letter
	        TextView t = (TextView)findViewById(R.id.letter);
		    t.setText(classMap.get((int)output.getData(0)));
		    
		    // Update letter history
		    TextView tv = (TextView)findViewById(R.id.letterHistory);
			tv.setText(tv.getText()+" "+classMap.get((int)output.getData(0)));
			while (tv.getLineCount() > 1) {
				tv.setText(tv.getText().toString().substring(1));
			}
		    
		    // Speak the letter, if not muted
		    if (mMuted == false) {
		    	ttsObj.speak(classMap.get((int)output.getData(0)), TextToSpeech.QUEUE_FLUSH, null);
		    }
		    
		    // If this was the first translation, call firstTranslate()
		    if (t.getVisibility() == View.GONE) {
		    	firstTranslate();
		    }
		}
		else {
			// No glove connected
			Toast.makeText(getApplicationContext(),"No glove connected",Toast.LENGTH_LONG).show();
		}
	}
	
	// Called when the user clicks the Connect glove item from the menu
	private void connectGlove() {
		
		MenuItem glvMenuItem = mMenu.findItem(R.id.action_con_glove);
		
        if (mGloveConnected) {
        	// Disconnect from glove
        	Singleton.getBGS().stop();
        	gloveDisconnected();
        }
        else {
        	// Connect to glove
        	if (mBluetoothAdapter == null) {
        	    // Device does not support Bluetooth
        		Toast.makeText(getApplicationContext(),"Your device does not support Bluetooth",Toast.LENGTH_LONG).show();
        	}
        	else {
        		// Device does support Bluetooth
        		if (!mBluetoothAdapter.isEnabled()) {
        			// Make a request to enable Bluetooth
        		    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        		    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        		}
        		else {
        			// Bluetooth already enabled
        			displayDeviceList();
        		}
        	}
        }
		
	}
	
	// Called when a connection to a glove has been established
	private void gloveConnected() {
		mGloveConnected = true;
		
		// Load and initialise the SVM
		AssetManager assetMgr = getAssets();
		try {
			InputStream input = assetMgr.open("net_svm.eg");
			svm = (SVM) EncogDirectoryPersistence.loadObject(input);
		} catch (IOException e) {
			// Could not load saved SVM
			Toast.makeText(getApplicationContext(), "Could not load saved SVM.", Toast.LENGTH_SHORT).show();
		}
		
		// Update the Connect glove item in the menu
		MenuItem glvMenuItem = mMenu.findItem(R.id.action_con_glove);
    	glvMenuItem.setTitle("Disconnect glove");
    	glvMenuItem.setIcon(R.drawable.ic_action_disconnect);
    	
    	// Move the arrow to the bottom
    	ImageView i = (ImageView)findViewById(R.id.arrowUp);
    	android.widget.RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams)i.getLayoutParams();
		params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT,0);
		params.addRule(RelativeLayout.ALIGN_PARENT_TOP,0);
		int idx = findViewById(R.id.bottom_bar).getId();
		params.addRule(RelativeLayout.ABOVE,idx);		
		params.addRule(RelativeLayout.CENTER_HORIZONTAL);
		i.setLayoutParams(params);
		i.setRotation(160); //API>=11
		i.setVisibility(View.VISIBLE);
		
		// Update the instructions
    	TextView t = (TextView)findViewById(R.id.instructions);
		t.setText("Make a sign then press translate");
		params = (RelativeLayout.LayoutParams)t.getLayoutParams();
		params.addRule(RelativeLayout.ABOVE,i.getId());	
		t.setLayoutParams(params);
		Typeface font = Typeface.createFromAsset(getAssets(), "ThrowMyHandsUpintheAir.ttf");
		t.setTypeface(font);
		t.setTextSize(30);
		android.view.ViewGroup.LayoutParams params2 = t.getLayoutParams();
		params2.width = 300;
		t.setLayoutParams(params2);
		
		// Remove letter history
	    TextView tv = (TextView)findViewById(R.id.letterHistory);
		tv.setText("");
		tv.setVisibility(View.GONE);
	}
	
	// Called when a connection to a glove is being attempted
	private void gloveConnecting() {
		// Update the instructions text box
		TextView t = (TextView)findViewById(R.id.instructions);
		t.setText("Connecting to glove...");
		android.view.ViewGroup.LayoutParams params = t.getLayoutParams();
		params.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
		t.setLayoutParams(params);
		RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) t.getLayoutParams();
		lp.addRule(RelativeLayout.CENTER_VERTICAL);
		lp.addRule(RelativeLayout.BELOW,0);	
		t.setLayoutParams(lp);
		Typeface font = Typeface.DEFAULT;
		t.setTypeface(font);
		t.setTextSize(20);
		t.setVisibility(View.VISIBLE);
				
		// Hide arrow
		ImageView i = (ImageView)findViewById(R.id.arrowUp);
		i.setVisibility(View.GONE);
	}
	
	// Called when a connection to a glove has been terminated intentionally
	private void gloveDisconnected() {
		mGloveConnected = false;
		svm = null;
		
		// Update the Disconnect glove item in the menu
		MenuItem glvMenuItem = mMenu.findItem(R.id.action_con_glove);
        glvMenuItem.setTitle("Connect glove");
        glvMenuItem.setIcon(R.drawable.ic_action_connect);
        
        // Hide the letter
        TextView t = (TextView)findViewById(R.id.letter);
		t.setVisibility(View.GONE);
		
		// Update the instructions text box
		t = (TextView)findViewById(R.id.instructions);
		t.setText("Disconnected from glove");
		android.view.ViewGroup.LayoutParams params = t.getLayoutParams();
		params.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
		t.setLayoutParams(params);
		RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) t.getLayoutParams();
		lp.addRule(RelativeLayout.CENTER_VERTICAL);
		lp.addRule(RelativeLayout.BELOW,0);	
		lp.addRule(RelativeLayout.ABOVE,0);	
		t.setLayoutParams(lp);
		t.setVisibility(View.VISIBLE);
		Typeface font = Typeface.DEFAULT;
		t.setTypeface(font);
		t.setTextSize(20);
		
		// Hide arrow
		ImageView i = (ImageView)findViewById(R.id.arrowUp);
		i.setVisibility(View.GONE);
	}
	
	// Called when the Translate button is first pressed
	private void firstTranslate() {
		// Show the letter
		TextView t = (TextView)findViewById(R.id.letter);
		t.setVisibility(View.VISIBLE);
		
		// Hide arrow
		ImageView i = (ImageView)findViewById(R.id.arrowUp);
		i.setVisibility(View.GONE);
		
		// Hide instructions
		t = (TextView)findViewById(R.id.instructions);
		t.setVisibility(View.GONE);
		
		// Show history
	    TextView tv = (TextView)findViewById(R.id.letterHistory);
		tv.setVisibility(View.VISIBLE);
	}
	
	// Called when a connection attempt to a glove has failed
	private void gloveConnFailed() {
		// Update the instructions text box
		TextView t = (TextView)findViewById(R.id.instructions);
		t.setText("Connection to the glove failed");
	}
	
	// Called when a connection to a glove has been terminated due to loss of connection
	private void gloveConnLost() {
		mGloveConnected = false;
		
		// Update the instructions text box
		TextView t = (TextView)findViewById(R.id.instructions);
		t.setText("Disconnected from the glove");
		android.view.ViewGroup.LayoutParams params = t.getLayoutParams();
		params.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
		t.setLayoutParams(params);
		RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) t.getLayoutParams();
		lp.addRule(RelativeLayout.CENTER_VERTICAL);
		lp.addRule(RelativeLayout.BELOW,0);	
		lp.addRule(RelativeLayout.ABOVE,0);	
		t.setLayoutParams(lp);
		Typeface font = Typeface.DEFAULT;
		t.setTypeface(font);
		t.setTextSize(20);
		t.setVisibility(View.VISIBLE);
		
		// Hide letter
		t = (TextView)findViewById(R.id.letter);
		t.setVisibility(View.GONE);
	}
	
	// Called when the Connect glove menu item is pressed and a Bluetooth connection is established
	private void displayDeviceList() {
		Log.d(TAG, "displayDeviceList()");
        
        // Get the UUID
        String uuid = sharedPrefs.getString("pref_key_uuid", "00001101-0000-1000-8000-00805f9b34fb");
        
        // Initialize the BluetoothGloveService from the Singleton
        Singleton.init();
        Singleton.getBGS().setParams(this, mHandler, uuid);
        
		// Launch the DeviceListActivity to see devices and do scans
        Intent serverIntent = new Intent(this, DeviceListActivity.class);
        startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
	}
	
	// Calibrates data passed using the calibration settings
	private double[] calibrateData(double[] datRow) {
		
		datRow[0] = ((datRow[0])-Float.parseFloat(sharedPrefs.getString("pref_fing_thumb_mcp_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_thumb_mcp_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_thumb_mcp_min","0")));
		datRow[1]= ((datRow[1])-Float.parseFloat(sharedPrefs.getString("pref_fing_thumb_pip_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_thumb_pip_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_thumb_pip_min","0")));
		datRow[2]= ((datRow[2])-Float.parseFloat(sharedPrefs.getString("pref_fing_index_mcp_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_index_mcp_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_index_mcp_min","0")));
		datRow[3]= ((datRow[3])-Float.parseFloat(sharedPrefs.getString("pref_fing_index_pip_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_index_pip_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_index_pip_min","0")));
		datRow[4]= ((datRow[4])-Float.parseFloat(sharedPrefs.getString("pref_fing_middle_mcp_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_middle_mcp_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_middle_mcp_min","0")));
		datRow[5]= ((datRow[5])-Float.parseFloat(sharedPrefs.getString("pref_fing_middle_pip_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_middle_pip_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_middle_pip_min","0")));
		datRow[6]= ((datRow[6])-Float.parseFloat(sharedPrefs.getString("pref_fing_ring_mcp_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_ring_mcp_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_ring_mcp_min","0")));
		datRow[7]= ((datRow[7])-Float.parseFloat(sharedPrefs.getString("pref_fing_ring_pip_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_ring_pip_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_ring_pip_min","0")));
		datRow[8]= ((datRow[8])-Float.parseFloat(sharedPrefs.getString("pref_fing_pinky_mcp_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_pinky_mcp_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_pinky_mcp_min","0")));
		datRow[9]= ((datRow[9])-Float.parseFloat(sharedPrefs.getString("pref_fing_pinky_pip_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_pinky_pip_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_pinky_pip_min","0")));
		datRow[10]= ((datRow[10])-Float.parseFloat(sharedPrefs.getString("pref_fing_touch_im_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_touch_im_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_touch_im_min","0")));
		datRow[11]= ((datRow[11])-Float.parseFloat(sharedPrefs.getString("pref_fing_touch_mr_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_touch_mr_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_touch_mr_min","0")));
		datRow[12]= ((datRow[12])-Float.parseFloat(sharedPrefs.getString("pref_fing_touch_rp_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_touch_rp_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_touch_rp_min","0")));
		datRow[13]=((datRow[13])-Float.parseFloat(sharedPrefs.getString("pref_fing_touch_itmb_min","0")))
				/(Float.parseFloat(sharedPrefs.getString("pref_fing_touch_itmb_max","1000"))-Float.parseFloat(sharedPrefs.getString("pref_fing_touch_itmb_min","0")));
		
		return datRow;
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) { 
	    // Inflate the menu items for use in the action bar
	    MenuInflater inflater = getMenuInflater();
	    inflater.inflate(R.menu.activity_main_actions, menu);
	    this.mMenu = menu;
	    return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    switch (item.getItemId()) {
        case R.id.action_con_glove:
        	// Request to launch the DeviceListActivity (needs Bluetooth enabled first)
            connectGlove();
            return true;
        case R.id.action_calib_wizard:
        	// Open the Calibration activity
        	if (mGloveConnected == true) {
        		Intent showCalibWizIntent = new Intent(this, CalibrationActivity.class);
        		startActivity(showCalibWizIntent);
        	}
        	else {
        		Toast.makeText(getApplicationContext(), "A glove must be connected to perform calibration.", Toast.LENGTH_SHORT).show();
        	}
		    return true;
        case R.id.action_settings:
        	// Open the Settings activity
        	Intent showSettingsIntent = new Intent(this, SettingsActivity.class);
		    startActivity(showSettingsIntent);
		    return true;
	    }
	    return false;
	}
	
}
