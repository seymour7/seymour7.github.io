package com.example.sasltranslator;

public class Singleton  {

    private static BluetoothGloveService bgs;

    public static void init() {
        bgs = new BluetoothGloveService();
    }

    public static BluetoothGloveService getBGS(){
        return bgs;
    }
    
}