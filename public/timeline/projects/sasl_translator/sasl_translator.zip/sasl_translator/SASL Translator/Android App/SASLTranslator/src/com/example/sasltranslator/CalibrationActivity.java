package com.example.sasltranslator;

import android.app.ActionBar;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Used to run the calibration wizard
 */
public class CalibrationActivity extends Activity {
	
	// The current state
	private int state;
	
	// Wizard states
	public static final int STATE_UNSTARTED = 1;
	public static final int STATE_FIRST_STEP = 2;
	public static final int STATE_SECOND_STEP = 3;
	public static final int STATE_THIRD_STEP = 4;
	public static final int STATE_FOURTH_STEP = 5;
	public static final int STATE_FINISHED = 6;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_calibration);
		
		setTitle("Calibration Wizard");
		
		// Activate back button
        ActionBar actionBar = getActionBar(); 
        actionBar.setDisplayHomeAsUpEnabled(true);
        
        // Initial state
        state = STATE_UNSTARTED;
	}
	
	// Moving to the next step
	public void nextStep(View view) {
		
		if (state == STATE_UNSTARTED)
		{
			state = STATE_FIRST_STEP;
			
			// Change image
			ImageView i = (ImageView)findViewById(R.id.calib_sign);
			i.setVisibility(View.VISIBLE);
			
			// Change instruction
			TextView t = (TextView)findViewById(R.id.calib_instr);
			t.setText("Stretch all your fingers as far out as possible, then click Next.");
			
			((Button)view).setText("Next");
		}
		else if (state == STATE_FIRST_STEP)
		{
			// Store data
			SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
			Editor editor = sharedPrefs.edit();
	    	editor.putString("pref_fing_thumb_mcp_max", Singleton.getBGS().datRow.get(0));
	    	editor.putString("pref_fing_thumb_pip_max", Singleton.getBGS().datRow.get(1));
	    	editor.putString("pref_fing_index_mcp_max", Singleton.getBGS().datRow.get(2));
	    	editor.putString("pref_fing_index_pip_max", Singleton.getBGS().datRow.get(3));
	    	editor.putString("pref_fing_middle_mcp_max", Singleton.getBGS().datRow.get(4));
	    	editor.putString("pref_fing_middle_pip_max", Singleton.getBGS().datRow.get(5));
	    	editor.putString("pref_fing_ring_mcp_max", Singleton.getBGS().datRow.get(6));
	    	editor.putString("pref_fing_ring_pip_max", Singleton.getBGS().datRow.get(7));
	    	editor.putString("pref_fing_pinky_mcp_max", Singleton.getBGS().datRow.get(8));
	    	editor.putString("pref_fing_pinky_pip_max", Singleton.getBGS().datRow.get(9));
	    	editor.putString("pref_fing_touch_im_min", Singleton.getBGS().datRow.get(10));
	    	editor.putString("pref_fing_touch_mr_min", Singleton.getBGS().datRow.get(11));
	    	editor.putString("pref_fing_touch_rp_min", Singleton.getBGS().datRow.get(12));
	    	editor.putString("pref_fing_touch_itmb_min", Singleton.getBGS().datRow.get(13));
	    	editor.commit();
	    	
	    	// Change state
			state = STATE_SECOND_STEP;
			
			// Change image
			ImageView i = (ImageView)findViewById(R.id.calib_sign);
			i.setImageResource(R.drawable.calib_a);
			
			// Change instruction
			TextView t = (TextView)findViewById(R.id.calib_instr);
			t.setText("Bend all your fingers, except your thumb, as much as possible, then click Next.");
		}
		else if (state == STATE_SECOND_STEP)
		{
			// Store data
			SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
			Editor editor = sharedPrefs.edit();
	    	editor.putString("pref_fing_index_mcp_min", Singleton.getBGS().datRow.get(2));
	    	editor.putString("pref_fing_index_pip_min", Singleton.getBGS().datRow.get(3));
	    	editor.putString("pref_fing_middle_mcp_min", Singleton.getBGS().datRow.get(4));
	    	editor.putString("pref_fing_middle_pip_min", Singleton.getBGS().datRow.get(5));
	    	editor.putString("pref_fing_ring_mcp_min", Singleton.getBGS().datRow.get(6));
	    	editor.putString("pref_fing_ring_pip_min", Singleton.getBGS().datRow.get(7));
	    	editor.putString("pref_fing_pinky_mcp_min", Singleton.getBGS().datRow.get(8));
	    	editor.putString("pref_fing_pinky_pip_min", Singleton.getBGS().datRow.get(9));
	    	editor.putString("pref_fing_touch_im_max", Singleton.getBGS().datRow.get(10));
	    	editor.putString("pref_fing_touch_mr_max", Singleton.getBGS().datRow.get(11));
	    	editor.putString("pref_fing_touch_rp_max", Singleton.getBGS().datRow.get(12));
	    	editor.commit();
	    	
	    	// Change state
			state = STATE_THIRD_STEP;
			
			// Change image
			ImageView i = (ImageView)findViewById(R.id.calib_sign);
			i.setImageResource(R.drawable.calib_e);
			
			// Change instruction
			TextView t = (TextView)findViewById(R.id.calib_instr);
			t.setText("Bend your thumb as much as possible, then click Next.");
		}
		else if (state == STATE_THIRD_STEP)
		{
			// Store data
			SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
			Editor editor = sharedPrefs.edit();
	    	editor.putString("pref_fing_thumb_mcp_min", Singleton.getBGS().datRow.get(0));
	    	editor.putString("pref_fing_thumb_pip_min", Singleton.getBGS().datRow.get(1));
	    	editor.commit();
			
	    	// Change state
			state = STATE_FOURTH_STEP;
			
			// Change image
			ImageView i = (ImageView)findViewById(R.id.calib_sign);
			i.setImageResource(R.drawable.calib_r);
			
			// Change instruction
			TextView t = (TextView)findViewById(R.id.calib_instr);
			t.setText("Activate the touch sensor for the letter R, then click Next.");
		}
		else if (state == STATE_FOURTH_STEP)
		{
			// Store data
			SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
			Editor editor = sharedPrefs.edit();
	    	editor.putString("pref_fing_touch_itmb_max", Singleton.getBGS().datRow.get(12));
	    	editor.commit();
	    	
	    	// Change state
			state = STATE_FINISHED;
			
			// Change image
			ImageView i = (ImageView)findViewById(R.id.calib_sign);
			i.setVisibility(View.GONE);
			
			 // Change instruction
			TextView t = (TextView)findViewById(R.id.calib_instr);
			t.setText("Calibration complete. Press Finish to return to the main screen");
			
			((Button)view).setText("Finish");
		}
		else if (state == STATE_FINISHED)
		{
			// Close the activity
			this.finish();
		}
	}
	
	// Back button
	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case android.R.id.home:
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
