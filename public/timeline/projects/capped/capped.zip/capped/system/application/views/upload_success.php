<?php $this->load->view('header'); ?>

<div id="sidebar-wrap">
	<div id="sidebar">
		<p>image only</p>
		<p><input type="text" value="<?php echo $this->config->item('base_image_url'); ?><?php echo $upload_data['file_origimg']; ?>" onclick="select_all(this)" class="copytext" size="26" /></p>
		<p>embed</p>
		<p><input type="text" value='<img src="<?php echo $this->config->item('base_image_url'); ?><?php echo $upload_data['file_origimg']; ?>" alt="image" />' onclick="select_all(this)" class="copytext" size="26" /></p>
		<p>forum</p>
		<p><input type="text" value="[url=<?php echo $this->config->item('base_image_url'); ?><?php echo $upload_data['file_origimg']; ?>][img]<?php echo $this->config->item('base_image_url'); ?><?php echo $upload_data['file_origimg']; ?>[/img][/url]" onclick="select_all(this)" class="copytext" size="26" /></p>
		<p>file info</p>
		<dl>
		  <dt>mime type</dt>
			<dd><?php echo $upload_data['file_type']; ?></dd>
		  <dt>file size</dt>
			<dd><?php echo $upload_data['file_size']; ?> kb</dd>
		  <dt>dimensions</dt>
			<dd><?php echo $upload_data['image_width']; ?> x <?php echo $upload_data['image_height']; ?></dd>
		</dl>
		<p><?php echo anchor('upload', 'Upload Another File!'); ?></p>
	</div>
</div>
<h3>Your image was successfully uploaded!</h3>



<a href="<?php echo $this->config->item('base_image_url'); ?><?php echo $upload_data['file_origimg']; ?>" title="image"><img src="<?php echo $this->config->item('base_image_url'); ?><?php echo $upload_data['file_name']; ?>" alt="image" /></a>

<?php $this->load->view('footer'); ?>