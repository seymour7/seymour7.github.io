</div>

<div id="footer">
	<div class="column-wrap">
		<div class="column">
			<p>Restrictions</p>
			<ul>
				<li>
					<p>Allowed file types:</p>
					<ul>
						<li>gif</li>
						<li>jpeg</li>
						<li>png</li>
						<li>tiff</li>
						<li>bmp</li>
					</ul>
				</li>
				<li>
					<p>Max file size:</p>
					<ul>
						<li>2048 KB</li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<div class="column-wrap">
		<div class="column">
			<p>Pages</p>
			<ul>
				<li><?php echo anchor('', 'Home'); ?></li>
			</ul>
			<p style="padding-top: 8px;">Info</p>
			<p>capped is a new database-free image hosting service. The site is currently in beta version.</p>
		</div>
	</div>
	<div class="column-wrap">
		<div class="column">
			<p>Friends</p>
			<ul>
				<li><?php echo anchor('http://locality.co.za', 'Locality'); ?></li>
				<li><?php echo anchor('http://stikked.com', 'Stikked'); ?></li>
			</ul>
			<p style="padding-top: 8px;">Stats</p>
			<ul>
				<li>
					<p>Total images</p>
					<ul>
						<li><?php
						$this->load->helper('common_functions');
						echo total_images("uploads/");?>
						</li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<p style="float: left; text-align: center; width: 700px; padding: 8px 0;">Page rendered in {elapsed_time} seconds<br />capped.co.za &copy; 2009 <?php echo anchor('http://seymour.za.net', 'Michael Seymour'); ?></p>
</div>

</body>
</html>