<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function total_images($dir)
{
	$count = 0;
	if (is_dir($dir))
	{
		if ($handle = opendir($dir))
		{
			while (($file = readdir($handle)) !== false)
			{
				if ( ! is_dir($dir.$file))
				{
					$count++;
				}
			}
			closedir($handle);
		}
	}
	return $count;
}
   

/* End of file common_functions_helper.php */
/* Location: ./system/application/helpers/common_functions_helper.php */