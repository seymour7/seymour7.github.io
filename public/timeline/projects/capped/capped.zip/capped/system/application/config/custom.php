<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Base Image Storage URL
|--------------------------------------------------------------------------
|
| URL to image storage root. Typically this will be imgs.yourdomain.co.za,
| WITH a trailing slash:
|
|	http://imgs.example.com/
|
*/
$config['base_image_url']	= "http://localhost/capped.co.za/uploads/";


/* End of file custom.php */
/* Location: ./system/application/config/custom.php */