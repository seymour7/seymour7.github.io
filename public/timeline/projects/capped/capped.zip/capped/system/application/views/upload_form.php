<?php $this->load->view('header'); ?>

<?php if ($error != "") {
	echo "<div class='error'>";
	echo "<h3>error</h3>";
	echo $error;
	echo "</div>";
}?>

<img src="<?php echo base_url(); ?>static/img/upload.png" alt="upload" />

<?php echo form_open_multipart('upload');?>
	<input type="file" name="userfile" size="20" />
	<input type="submit" value="Upload" />
</form>

<?php $this->load->view('footer'); ?>