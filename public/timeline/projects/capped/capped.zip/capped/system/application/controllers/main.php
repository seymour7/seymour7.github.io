<?php

class Main extends Controller {

	function __construct()
	{
		parent::Controller();
		$this->load->helper('form');	
	}
	
	function index()
	{
		$this->load->view('upload_form', array('error' => '' ));
	}
}

/* End of file main.php */
/* Location: ./system/application/controllers/main.php */