<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>capped.co.za - elegant image hosting</title>
<link rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css" type="text/css" />
<script type="text/javascript">
function select_all(obj) {
	var text_val=eval(obj);
	text_val.focus();
	text_val.select();
}
</script>
</head>
<body>

<div id="header-wrap">
	<div id="header">
		<img src="<?php echo base_url(); ?>static/img/slogan.png" alt="slogan" id="slogan" />
		<a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>static/img/header.png" alt="header" id="header-img" /></a>
	</div>
</div>

<div id="container"<?php if (isset($upload_data['sidebar'])) { if ($upload_data['sidebar'] == TRUE) { echo " style='background: url(static/img/sidebar.png) repeat-y right'"; } } ?>>