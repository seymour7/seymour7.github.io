<?php

class Upload extends Controller {

	function __construct()
	{
		parent::Controller();
		$this->load->helper('form');	
	}
	
	function index()
	{
		$config['upload_path'] = "uploads/";
		$config['allowed_types'] = 'gif|jpeg|png|tiff|bmp';
		$config['max_size']	= '2048';
		$config['max_width'] = '0';
		$config['max_height'] = '0';

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload())
		{
			$error = array('error' => $this->upload->display_errors());

			$this->load->view('upload_form', $error);
		}	
		else
		{
			//Rename the newly uploaded file
			$data = $this->upload->data();
			$file_name = $this->rename($data['full_path'], $data['file_path'], $data['file_ext']);
			
			$data = array('upload_data' => $this->upload->data());
			$data['upload_data']['file_origimg'] = $file_name; // Used for the <a> link in the view incase the image is resized and file_name changes to the /resized dir
			$data['upload_data']['sidebar'] = TRUE; // Indicates that a sidebar must be made
			
			//check if the image width is too wide for the page design
			if ($data['upload_data']['image_width'] > 500)
			{
				$this->resize($data['upload_data']['file_path'], $file_name, 468);
				$data['upload_data']['file_name'] = "resized/".$file_name;
			}
			else
			{
				$data['upload_data']['file_name'] = $file_name; // Change the new file name variable to our custom pimped out filename
			}
			
			$this->load->view('upload_success', $data);
		}
	}
	
	function rename($full_path, $file_path, $file_ext)
	{
		//Generate new filename
		$new_filename = $this->unique_filename($file_path, $file_ext);
		//Put that new filename into the full path
		$new_path = $file_path.$new_filename.$file_ext;
		
		$this->load->library('ftp');
		
		if ( ! rename($full_path, $new_path))
		{
			echo "fail whale";
		}
		else
		{
			return $new_filename.$file_ext;
		}
	}
	
	function unique_filename($file_path, $file_ext)
	{
		$filename = $this->filename_generate();
		if (file_exists($file_path.$filename.$file_ext))
		{
			return $this->unique_filename($file_path, $file_ext);
		}
		else
		{
			return $filename;
		}
	}
	
	function filename_generate()
	{
		$this->load->helper('string');
		
		return date("ymd").date("Hi")."-".strtolower(random_string('alnum', 2));
	}
	
	function resize($image_path, $image_name, $width)
	{
		$config['image_library'] = 'gd2';
		$config['source_image'] = $image_path.$image_name;
		$config['new_image'] = $image_path."resized/".$image_name;
		$config['maintain_ratio'] = TRUE;
		$config['width'] = $width;
		$config['height'] = $width;
   
		$this->load->library('image_lib', $config);
   
		$this->image_lib->resize();
	}
}

/* End of file upload.php */
/* Location: ./system/application/controllers/upload.php */