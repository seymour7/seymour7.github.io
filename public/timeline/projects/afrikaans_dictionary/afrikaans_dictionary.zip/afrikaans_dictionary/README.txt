This application is for a community based Afrikaans-English dictionary. It is built using CodeIgniter 1.7.0.

Relevant directories:
---------------------
 * Controllers:   /system/application/controllers/
 * Views:         /system/application/views/
 * Libraries:     /system/application/libraries/
 * CSS/JS/images: /static/

Note:
-----
1. This application uses set_magic_quotes_runtime(). Since PHP 5.3 this function has been deprecated and will raise an E_DEPRECATED warning upon execution. Since PHP 5.4 this function will also raise an E_CORE_ERROR on trying to enable magic quotes.
2. This application also assigns the return value of new by reference which is now deprecated.