<?php

class Add extends Controller {

	function Add()
	{
		parent::Controller();	
	}
	
	function index()
	{
		if (isset($_POST['engword']) or isset($_POST['afrword']))
		{
			$this->load->library('validation');
			
			// Important: The function to check whther the word is a duplicate is a rule on the 'wordtype' field:
			$rules['engword']	= "trim|required|max_length[25]|xss_clean";
			$rules['afrword']	= "trim|required|max_length[25]|xss_clean";
			$rules['wordtype']	= "numeric|callback_wordduplicate_check";
				
			$this->validation->set_rules($rules);
					
			if ($this->validation->run() == FALSE)
			{
				$data['message'] = "Error occured.".$this->validation->error_string;
			}
			else
			{
				$this->load->database();
			
				$data = array(
					'engword' => $_POST['engword'],
					'afrword' => $_POST['afrword'],
					'wordtype' => $_POST['wordtype']
				);

				$this->db->insert('words', $data); 
				
				$data['message'] = "Thank you. Your translation for the word '".$_POST['engword']."' was added successfully.";
			}
		}
		else
		{
			$data['message'] = "";
		}
		
		$this->load->view('add', $data);
	}
	
	// Function to check wether the submitted word is an exact duplicate of another, based on the engword, afrword and wordtype:
	function wordduplicate_check($type)
	{
		$this->load->database();

		$query = $this->db->query('SELECT * FROM words WHERE engword = "'.$_POST['engword'].'" AND afrword = "'.$_POST['afrword'].'" AND wordtype = "'.$_POST['wordtype'].'"');
		
		if ($query->num_rows() > 0)
		{
			$this->validation->set_message('wordduplicate_check', 'The %s field has an Afrikaans translation that is already used for this english word.');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}

}

?>