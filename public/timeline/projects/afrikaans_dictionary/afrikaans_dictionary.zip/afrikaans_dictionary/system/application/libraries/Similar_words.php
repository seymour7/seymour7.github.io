<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Similar_words {

    function Similar_words($params)
    {    
		// Database querying:
		$CI =& get_instance();
		$CI->load->database();
		$similarwords = $CI->db->query('SELECT DISTINCT engword FROM words WHERE engword LIKE "%'.$params['word'].'%" AND engword != "'.$params['word'].'"');
		
		// HTML parsing:
		if ($similarwords->num_rows() > 0): ?>
        <h3>Similar words</h3>
        <ul>
        <?php foreach ($similarwords->result() as $row): ?>
        <li><a href="<?=base_url()?>word/<?=$row->engword?>"><?=$row->engword?></a></li>
        <?php endforeach; ?>
        </ul>
        <?php endif;
    }
}

?>