<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Afrikaans Dictionary</title>
<link href="<?=base_url()?>static/stylesheets/stylesheet.css" type="text/css" rel="stylesheet" />
<?php if ($this->uri->segment(1) == "word"): ?>
<script src="<?=base_url()?>static/js/jquery.js" language="javascript"></script>
<script language="javascript">
$(function() {
	// Document is ready
	$(".goodorbad-box").attr("style","display: inline;");
	$(".markasspam-box").attr("style","display: inline;");
});
function goodorbad(type, id)
{
	$.post("<?=base_url()?>goodorbad", { type: type, id: id }, 
		function(data) {
			
			// If the guy has marked something as spam:
			if (type == "spam")
			{
				if (data == "success")
				{
					$("#markasspam-box-" + id).hide().html("Thank you.").fadeIn();
				}
				else
				{
					$("#markasspam-box-" + id).hide().html("Error occured.").fadeIn();
				}
			}
			// If the guy has voted a translation as good or bad:
			else
			{
				if (data == "success")
				{
					$("#goodorbad-box-" + id).hide().html("Thank you.").fadeIn();
					var newvalue = parseInt($("#" + type + "value-" + id).html()) + 1;
					$("#" + type + "value-" + id).html(newvalue);
				}
				else
				{
					$("#goodorbad-box-" + id).hide().html("Error occured.").fadeIn();
				}
			}
		}
	);
}
</script>
<?php endif; ?>
<?php if ($this->uri->segment(1) == "add"): ?>
<script src="<?=base_url()?>static/js/jquery.js" language="javascript"></script>
<script language="javascript">
$(function() {
	// Document is ready
	//$(".goodorbad-box").attr("style","display: inline;");
	//$(".markasspam-box").attr("style","display: inline;");
	$("#wordtype-info dd").hide();
	$("#wordtype-info dt").click(function() {
		var info = $(this).next("dd").html();
		$("#info-box").html(info);
	})
});
function insert_symbol(symbol)
{
	if (symbol != "149")
	{
		$(".afrword-textbox").val($(".afrword-textbox").val() + String.fromCharCode(symbol));
	}
	else
	{
		$(".afrword-textbox").val($(".afrword-textbox").val() + "’n");
	}
}
</script>
<?php endif; ?>

</head>

<body>
<div id="header">
<img src="<?=base_url()?>static/images/header.jpg" alt="Afrikaans Dictionary" />
    <ul id="nav">
        <li><a href="<?=base_url()?>"><img src="<?=base_url()?>static/images/nav/home.png" alt="Home" />Home</a></li>
        <li><a href="<?=base_url()?>add"><img src="<?=base_url()?>static/images/nav/add.png" alt="Add" />Add</a></li>
        <li><a href="<?=base_url()?>browse"><img src="<?=base_url()?>static/images/nav/browse.png" alt="Browse" />Browse</a></li>
    	<li><a href="<?=base_url()?>contact"><img src="<?=base_url()?>static/images/nav/contact.png" alt="Contact" />Contact</a></li>
	</ul>
</div>