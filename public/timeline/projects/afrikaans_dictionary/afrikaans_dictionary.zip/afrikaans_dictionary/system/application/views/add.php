<?php $this->load->view('header'); ?>
<div id="content">

<?php if ($message != ""): ?>
<div id="message">
<?=$message?>
</div>
<?php endif; ?>

<h1>Add word:</h1>

<div id="addword-info">
<ul>
	<li>Please submit all translations in <b>lower case</b> (ie. not using capital letters) unless the word specifically needs capital letters.</li>
</ul>
</div>

<form action="<?=base_url()?>add" method="post">
	<dl>
    <dt>English word:</dt>
    <dd>
	<?php if ($this->uri->segment(2) == ""):?>
    <input name="engword" type="text">
    <?php elseif (strlen($this->uri->segment(2)) < 25): ?>
    <input name="engword" type="hidden" value="<?=$this->uri->segment(2)?>"><?=$this->uri->segment(2)?>
    <?php else: redirect('add') ?>
	<?php endif; ?>
    
    </dd>
    <dt>Afrikaans word:</dt>
    <dd><input name="afrword" type="text" class="afrword-textbox"></dd>
    <dt>Symbol:</dt>
    <dd>
		<span><a href="javascript:void(0)" class="symbol-box" onclick="insert_symbol('234')">&ecirc;</a></span>
		<span><a href="javascript:void(0)" class="symbol-box" onclick="insert_symbol('235')">&euml;</a></span>
		<span><a href="javascript:void(0)" class="symbol-box" onclick="insert_symbol('251')">&ucirc;</a></span>
		<span><a href="javascript:void(0)" class="symbol-box" onclick="insert_symbol('244')">&ocirc;</a></span>
		<span><a href="javascript:void(0)" class="symbol-box" onclick="insert_symbol('149')">&rsquo;n</a></span>
    </dd>
    <dt>Word type:</dt>
    <dd><select name="wordtype">
    	<option value="def">Choose...</option>
        <option value="0">Adjective</option>
        <option value="1">Adverb</option>
        <option value="2">Article</option>
        <option value="3">Conjunction</option>
        <option value="4">Interjection</option>
        <option value="5">Noun</option>
        <option value="6">Preposition</option>
        <option value="7">Pronoun</option>
        <option value="8">Verb</option>
    </select></dd>
    </dl>
    <button type="submit">Add Word</button>
</form>

<div id="wordtype-info">
<dl>
<dt><a href="javascript:void(0)">Adjective</a></dt>
<dd><h4>Adjective</h4>A word that describes or qualifies a noun or pronoun</dd>
<dt><a href="javascript:void(0)">Adverb</a></dt>
<dd><h4>Adverb</h4>A word that modifies a verb, an adjective, another adverb, or a sentence, e.g. 'happily', 'very', or 'frankly'</dd>
<dt><a href="javascript:void(0)">Article</a></dt>
<dd><h4>Article</h4>A word used with a noun that specifies whether the noun is definite or indefinite. In English the indefinite articles are 'a' and 'an', and the definite article is 'the'.</dd>
<dt><a href="javascript:void(0)">Conjunction</a></dt>
<dd><h4>Conjunction</h4>A word that is used to link sentences, clauses, phrases, or words, e.g. 'and', 'but', or 'if'</dd>
<dt><a href="javascript:void(0)">Interjection</a></dt>
<dd><h4>Interjection</h4>A sound, word, or phrase that expresses a strong emotion such as pain or surprise but otherwise has no meaning</dd>
<dt><a href="javascript:void(0)">Noun</a></dt>
<dd><h4>Noun</h4>A word or group of words used as the name of a class of people, places, or things, or of a specific person, place, or thing</dd>
<dt><a href="javascript:void(0)">Preposition</a></dt>
<dd><h4>Preposition</h4>A member of a set of words used in close connection with, and usually before, nouns and pronouns to show their relation to another part of a clause. An example is 'off' in 'He fell off his bike' and 'What did he fall off?'</dd>
<dt><a href="javascript:void(0)">Pronoun</a></dt>
<dd><h4>Pronoun</h4>A word that substitutes for a noun or a noun phrase, e.g. 'I', 'you', 'them', 'it', 'ours', 'who', 'which', 'myself', and 'anybody'. English pronouns differ from nouns in sometimes having an objective form, e.g. 'her' for 'she' and 'me' for 'I'.</dd>
<dt><a href="javascript:void(0)">Verb</a></dt>
<dd><h4>Verb</h4>A word used to show that an action is taking place or to indicate the existence of a state or condition, or the part of speech to which such a word belongs</dd>
</dl>
<div id="info-box" style="margin-top: 20px;">Click on a word above to views its meaning.</div>
</div>

</div>
<?php $this->load->view('footer'); ?>