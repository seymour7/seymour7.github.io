<?php $this->load->view('header'); ?>
<div id="content">

<?php if(isset($message)): ?>
<div id="message">
<?=$message?>
</div>
<?php endif; ?>

<h1>English word:</h1>
<form action="<?=base_url()?>search" method="post">
	<input name="searchword" type="text" />
</form>

<div id="moreinfo">
<h2>How this site works</h2>
<p>This afrikaans dictionary is purely <b>community based</b>, ie. the translations are created and managed by you, the visitors. Anybody, including you, may <b>add a translation</b> for a word and it will be instantly added to the database. However, when others visit you translation they will be able to <b>rate the translation</b> as good or bad, depending on its accuracy. This should keep the best translations at the top of the list. If you happen to find a word that is completely offensive or just plain spam you may also mark that translation as <b>spam</b>. If you were to do this, the translation would not be deleted straight away; a moderator will then need to confirm that it really is spam before deleting it.</p>
</div>

</div>
<?php $this->load->view('footer'); ?>