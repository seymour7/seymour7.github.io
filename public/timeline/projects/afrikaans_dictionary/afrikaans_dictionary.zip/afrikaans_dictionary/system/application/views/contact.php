<?php $this->load->view('header'); ?>
<div id="content">

<?php if ($message != ""): ?>
<div id="message">
<?=$message?>
</div>
<?php endif; ?>

<h1>Contact me:</h1>

<form action="<?=base_url()?>contact" method="post" id="contactform">
    <input name="yourname" type="text" value="Your name" onclick="if (this.value == 'Your name') { this.value = '' }" onblur="if (this.value == '') { this.value = 'Your name' }">
    <input name="youremail" type="text" value="Your email" onclick="if (this.value == 'Your email') { this.value = '' }" onblur="if (this.value == '') { this.value = 'Your email' }">
    <textarea name="yourmessage" cols="55" rows="10" value="Your message" onclick="if (this.value == 'Your message') { this.value = '' }" onblur="if (this.value == '') { this.value = 'Your message' }"></textarea>
    <button type="submit">Submit message</button>
</form>

</div>
<?php $this->load->view('footer'); ?>