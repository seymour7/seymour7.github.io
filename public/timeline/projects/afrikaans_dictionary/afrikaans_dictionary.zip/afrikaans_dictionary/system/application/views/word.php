<?php $this->load->view('header'); ?>

<div id="content">

<h1>Translations for &quot;<?=$word?>&quot;</h1>

<ol start="<?php if ($this->uri->segment(3) != "") { echo ($this->uri->segment(3) * 5 - 4); } else { echo "1"; }?>">

<?php foreach ($query->result() as $row): ?>

<li class="translation-box">

<?php
switch ($row->wordtype)
{
	case 0: $wordtype = "Adjective"; break;
	case 1: $wordtype = "Adverb"; break;
	case 2: $wordtype = "Article"; break;
	case 3: $wordtype = "Conjunction"; break;
	case 4: $wordtype = "Interjection"; break;
	case 5: $wordtype = "Noun"; break;
	case 6: $wordtype = "Preposition"; break;
	case 7: $wordtype = "Pronoun"; break;
	case 8: $wordtype = "Verb"; break;
	default: $wordtype = "Unknown";
}
?>

<?=$row->afrword?>&nbsp;(<?=$wordtype?>)

<div class="translation-meta">
    <div class="goodorbad-box" id="goodorbad-box-<?=$row->id?>">
    
    <a href="javascript:void(0)" title="Good" onclick="goodorbad('good', '<?=$row->id?>')"><img src="<?=base_url()?>static/images/good.png" alt="Good"></a>
    <a href="javascript:void(0)" title="Bad" onclick="goodorbad('bad', '<?=$row->id?>')"><img src="<?=base_url()?>static/images/bad.png" alt="Bad"></a>
    
    </div>
    
(<span id="goodvalue-<?=$row->id?>"><?=$row->good?></span>&nbsp;good and <span id="badvalue-<?=$row->id?>"><?=$row->bad?></span>&nbsp;bad)
<div class="markasspam-box" id="markasspam-box-<?=$row->id?>">
<a href="javascript:void(0)" title="Mark as spam" onclick="goodorbad('spam', '<?=$row->id?>')"><img src="<?=base_url()?>static/images/spam.png" alt="Mark as spam"></a>
</div>
</div>

</li>

<?php endforeach; ?>

</ol>

<?php
// Pagination:
if ($this->uri->segment(3) == "")
{
	$page = 1;
}
else
{
	$page = $this->uri->segment(3);
}
?>     
<div id="pagination">
    <?php if ($page != 1): ?>
    	<a href="<?=base_url()?>word/<?=$word?>/<?=$page - 1?>">Previous page</a>
    <?php endif; ?>
    <?php if ($is_next->num_rows() > 0): ?>
        <a href="<?=base_url()?>word/<?=$word?>/<?=$page + 1?>">Next page</a>
    <?php endif; ?>
</div>


<div class="box">

<?php 
// Get the similar words:
$params['word'] = $word;
$this->load->library('Similar_words', $params);
?>

<?php 
// Get the close words:
$params['word'] = $word;
$this->load->library('Close_words', $params);
?>

</div>

</div>

<?php $this->load->view('footer'); ?>