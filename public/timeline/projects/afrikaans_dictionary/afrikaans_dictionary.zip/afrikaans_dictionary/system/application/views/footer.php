<div id="footer">
	<p>Afrikaans Dictionary &copy; 2008 Michael Seymour | Page rendered in {elapsed_time} seconds</p>
</div>
</body>
</html>