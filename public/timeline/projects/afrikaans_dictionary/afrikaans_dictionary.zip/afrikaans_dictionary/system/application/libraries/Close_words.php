<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Close_words {

    function Close_words($params)
    {    
		
		// Database querying:
		$CI =& get_instance();
		$CI->load->database();
		$closewords_next = $CI->db->query('SELECT DISTINCT engword FROM words WHERE engword > "'.$params['word'].'" ORDER BY engword ASC LIMIT 5');
		$closewords_prev = $CI->db->query('SELECT DISTINCT engword FROM words WHERE engword < "'.$params['word'].'" ORDER BY engword DESC LIMIT 5');
		
		
		// HTML parsing:
		?>
		<h3>Close words</h3>
		<ul>
		<?php
        
		$row = array_reverse($closewords_prev->result_array());
		foreach ($row as $row): ?>
		
		<li><a href="<?=base_url()?>word/<?=$row['engword']?>"><?=$row['engword']?></a></li>
		<?php endforeach; ?>
        
        <li><em><?=$params['word']?></em></li>
        
        <?php foreach ($closewords_next->result() as $row): ?>
        <li><a href="<?=base_url()?>word/<?=$row->engword?>"><?=$row->engword?></a></li>
        <?php endforeach; ?>
        </ul>
		<?php
    }
}

?>