<?php

class Goodorbad extends Controller {

	function Goodorbad()
	{
		parent::Controller();	
	}
	
	function index()
	{
		if (isset($_POST['type']) and isset($_POST['id']))
		{
			$this->load->database();
			
			$query = $this->db->query('SELECT '.$_POST['type'].' FROM words WHERE id = "'.$_POST['id'].'"');
			if ($query->num_rows() > 0)
			{
				$row = $query->row_array();
				$newno = $row[$_POST['type']] +1;
				
				$query = $this->db->query("UPDATE words SET ".$_POST['type']." = '{$newno}' WHERE id = ".$_POST['id']);
				if ($this->db->affected_rows() > 0)
				{
					echo "success";
				}
				else
				{
					echo "failure";
				}
			}
			else
			{
				echo "failure";
			}
		}
		else
		{
			redirect();
		}
	}
}

?>