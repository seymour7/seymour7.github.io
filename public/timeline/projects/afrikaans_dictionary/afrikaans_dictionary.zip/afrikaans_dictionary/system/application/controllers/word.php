<?php

class Word extends Controller {

	function Word()
	{
		parent::Controller();	
	}
	
	function index()
	{
		if ($this->uri->segment(2) != "")
		{
			// loading some helpers
			$this->load->helper('security');
			
			// clean the word entered in the url
			$word = xss_clean($this->uri->segment(2));
			
			// query the db with the cleaned word
			$this->load->database();
			
				// some pagination stuff:
				if ($this->uri->segment(3) == "" or $this->uri->segment(3) == "1")
				{
					$page = 0;
				}
				else
				{
					$page = $this->uri->segment(3) * 5 - 5;
				}
			
			// get the 5 words from the table
			$data['query'] = $this->db->query('SELECT * FROM words WHERE engword = "'.$word.'" ORDER BY good - bad DESC LIMIT '.$page.', 5');
			
			// pagination - if their is gonna be some shiz on the next page
			$data['is_next'] = $this->db->query('SELECT * FROM words WHERE engword = "'.$word.'" ORDER BY good - bad DESC LIMIT '.($page + 5).', 5');
			
			if($data['query']->num_rows() < 1)
			{
				// FAILZORFLAKES
				redirect();
			}
			else
			{
				$data['word'] = $word;
				$this->load->view('word', $data);
			}
		}
		else
		{
			redirect();
		}		
	}
}

?>