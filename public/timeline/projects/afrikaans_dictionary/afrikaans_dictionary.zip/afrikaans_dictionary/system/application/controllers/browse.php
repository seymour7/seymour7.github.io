<?php

class Browse extends Controller {

	function Browse()
	{
		parent::Controller();	
	}
	
	function index()
	{
		$this->load->database();
		
		$entries = 20;

				// some pagination stuff:
				if ($this->uri->segment(3) == "" or $this->uri->segment(3) == "1")
				{
					$page = 0;
				}
				else
				{
					$page = $this->uri->segment(3) * $entries - $entries;
				}
				// some more pagination stuff - wait, more like category stuff
				if ($this->uri->segment(2) == "" or $this->uri->segment(2) == "all")
				{
					$where = "";
				}
				else
				{
					$where = "WHERE LEFT(engword,1) = '".$this->uri->segment(2)."' ";
				}
		
		$data['query'] = $this->db->query('SELECT DISTINCT engword FROM words '.$where.'ORDER BY engword LIMIT '.$page.', '.$entries.'');
		
		// pagination - if their is gonna be some shiz on the next page
		$data['is_next'] = $this->db->query('SELECT DISTINCT engword FROM words '.$where.'ORDER BY engword DESC LIMIT '.($page + $entries).', '.$entries.'');
		
		if($data['query']->num_rows() < 1)
		{
			// FAILZORFLAKES
			redirect();
		}
		else
		{
			$this->load->view('browse', $data);
		}
		
	}
}

?>