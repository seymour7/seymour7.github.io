<?php $this->load->view('header'); ?>
<div id="content">

<ul id="alphabet">
<li><a href="<?=base_url()?>browse/all">All</a></li>
<li><a href="<?=base_url()?>browse/A">A</a></li>
<li><a href="<?=base_url()?>browse/B">B</a></li>
<li><a href="<?=base_url()?>browse/C">C</a></li>
<li><a href="<?=base_url()?>browse/D">D</a></li>
<li><a href="<?=base_url()?>browse/E">E</a></li>
<li><a href="<?=base_url()?>browse/F">F</a></li>
<li><a href="<?=base_url()?>browse/G">G</a></li>
<li><a href="<?=base_url()?>browse/H">H</a></li>
<li><a href="<?=base_url()?>browse/I">I</a></li>
<li><a href="<?=base_url()?>browse/J">J</a></li>
<li><a href="<?=base_url()?>browse/K">K</a></li>
<li><a href="<?=base_url()?>browse/L">L</a></li>
<li><a href="<?=base_url()?>browse/M">M</a></li>
<li><a href="<?=base_url()?>browse/N">N</a></li>
<li><a href="<?=base_url()?>browse/O">O</a></li>
<li><a href="<?=base_url()?>browse/P">P</a></li>
<li><a href="<?=base_url()?>browse/Q">Q</a></li>
<li><a href="<?=base_url()?>browse/R">R</a></li>
<li><a href="<?=base_url()?>browse/S">S</a></li>
<li><a href="<?=base_url()?>browse/T">T</a></li>
<li><a href="<?=base_url()?>browse/U">U</a></li>
<li><a href="<?=base_url()?>browse/V">V</a></li>
<li><a href="<?=base_url()?>browse/W">W</a></li>
<li><a href="<?=base_url()?>browse/X">X</a></li>
<li><a href="<?=base_url()?>browse/Y">Y</a></li>
<li><a href="<?=base_url()?>browse/Z">Z</a></li>
</ul>

<ul>
<?php foreach ($query->result() as $row): ?>
<li><a href="<?=base_url()?>word/<?=$row->engword?>"><?=$row->engword?></a></li>
<?php endforeach; ?>
</ul>

<?php
// Pagination:
if ($this->uri->segment(3) == "")
{
	$page = 1;
}
else
{
	$page = $this->uri->segment(3);
}
// some more pagination stuff - wait, more like category stuff
if ($this->uri->segment(2) == "")
{
	$urlcat = "all";
}
else
{
	$urlcat = $this->uri->segment(2);
}
?>     
<div id="pagination">
    <?php if ($page != 1): ?>
    	<a href="<?=base_url()?>browse/<?=$urlcat?>/<?=$page - 1?>">Previous page</a>
    <?php endif; ?>
    <?php if ($is_next->num_rows() > 0): ?>
        <a href="<?=base_url()?>browse/<?=$urlcat?>/<?=$page + 1?>">Next page</a>
    <?php endif; ?>
</div>

</div>
<?php $this->load->view('footer'); ?>