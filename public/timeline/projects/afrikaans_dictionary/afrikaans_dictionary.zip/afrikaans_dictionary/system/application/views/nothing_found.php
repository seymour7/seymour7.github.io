<?php $this->load->view('header'); ?>

<div id="content">

<h1>Nothing found!</h1>
<p>The word &quot;<?=$word?>&quot; was not found. Would you like to:</p>
<ul>
	<li><a href="<?=base_url()?>">Make another search?</a></li>
	<li><a href="<?=base_url()?>add/<?=$word?>">Add the translation for the word &quot;<?=$word?>&quot;?</a></li>
</ul>

<div class="box">

<?php 
// Get the similar words:
$params['word'] = $word;
$this->load->library('Similar_words', $params);
?>

</div>

</div>

<?php $this->load->view('footer'); ?>