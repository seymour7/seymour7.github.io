<?php

class Contact extends Controller {

	function Contact()
	{
		parent::Controller();	
	}
	
	function index()
	{
		if (isset($_POST['yourname']) or isset($_POST['youremail']) or isset($_POST['yourmessage']))
		{
			$this->load->library('validation');
			
			$rules['yourname']	= "trim|required|max_length[50]|xss_clean|callback_yourname_check";
			$rules['youremail']	= "trim|required|max_length[50]|valid_email|xss_clean|callback_youremail_check";
			$rules['yourmessage']	= "trim|required|max_length[500]|xss_clean|callback_yourmessage_check";
				
			$this->validation->set_rules($rules);
					
			if ($this->validation->run() == FALSE)
			{
				$data['message'] = "Error occured.".$this->validation->error_string;
			}
			else
			{
				$this->load->database();
			
				$data = array(
					'name' => $_POST['yourname'],
					'email' => $_POST['youremail'],
					'message' => $_POST['yourmessage']
				);

				$this->db->insert('contact', $data); 
				
				$data['message'] = "Thank you. Your message has been sent successfully.";
			}
		}
		else
		{
			$data['message'] = "";
		}
		
		$this->load->view('contact', $data);
	}
	
	function yourname_check($str)
	{
		if ($str == 'Your name')
		{
			$this->validation->set_message('yourname_check', 'The %s field can not be left empty.');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}
	function youremail_check($str)
	{
		if ($str == 'Your email')
		{
			$this->validation->set_message('youremail_check', 'The %s field can not be left empty.');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}
	function yourmessage_check($str)
	{
		if ($str == 'Your message')
		{
			$this->validation->set_message('yourmessage_check', 'The %s field can not be left empty.');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}

}

?>