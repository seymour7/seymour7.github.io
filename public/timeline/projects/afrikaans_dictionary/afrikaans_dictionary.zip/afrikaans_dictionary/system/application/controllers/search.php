<?php

class Search extends Controller {

	function Search()
	{
		parent::Controller();	
	}
	
	function index()
	{
		if(isset($_POST['searchword']))
		{
			$this->load->library('validation');
			
			$rules['searchword']	= "trim|required|max_length[25]|xss_clean";
				
			$this->validation->set_rules($rules);
					
			if ($this->validation->run() == FALSE)
			{
				$data['message'] = "Error occured.".$this->validation->error_string;
				$this->load->view('home', $data);
			}
			
			else
			{
				$this->load->database();
			
				$query = $this->db->query('SELECT * FROM words WHERE engword = "'.$_POST['searchword'].'"');
				
				if($query->num_rows() < 1)
				{
					$data['word'] = $_POST['searchword'];
					
					$this->load->view('nothing_found', $data);
				}
				else
				{
					redirect('word/'.$_POST['searchword']);
				}
				
				$data['message'] = "Thank you. Your translation for the word '".$_POST['searchword']."' was added successfully.";
			}
		}
		else
		{
			redirect();
		}
	}
}

?>